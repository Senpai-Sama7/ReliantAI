// Notifications.jsx — Unified Notification Center (Platform)

const NOTIF_DATA = [
  { id:'n001', cat:'ALERT',      service:'money',       color:'#ef4444', title:'LIFE_SAFETY — DSP-2025-8821', body:'Rodriguez, M. dispatched to 4821 Westheimer Rd. ETA 8 min. 911 escalated.', ts:'14:32', read:false, link:'money' },
  { id:'n002', cat:'ALERT',      service:'apex',        color:'#7c5cfc', title:'HITL required: wf-a9c3-d812', body:'Confidence 0.63 · Stakes HIGH · T3 Contested tier. Decision pending.', ts:'14:31', read:false, link:'apex' },
  { id:'n003', cat:'ALERT',      service:'cleardesk',   color:'#00d4aa', title:'Document escalated: INV-2025-0441', body:'$52,400 invoice. Confidence 0.61 below threshold. Assigned Chen, R.', ts:'14:31', read:false, link:'cleardesk' },
  { id:'n004', cat:'INSIGHT',    service:'bap',         color:'#FF6E00', title:'Anomaly detected: dispatch surge +340%', body:'HVAC dispatch volume 340% above 30-day baseline due to 96°F heat event.', ts:'14:29', read:false, link:'bap' },
  { id:'n005', cat:'SYSTEM',     service:'integration', color:'#00ff7a', title:'Saga sg-0041 completed',         body:'3/3 steps completed. ClearDesk → transform → publish. Duration: 3.2s.', ts:'14:30', read:true, link:'integration' },
  { id:'n006', cat:'CONVERSION', service:'money',       color:'#22c55e', title:'Conversion: Martinez HVAC Supply', body:'Revenue attributed: $8,400. Campaign: Summer HVAC Surge. Reply time: 4 min.', ts:'14:18', read:true, link:'money' },
  { id:'n007', cat:'SYSTEM',     service:'integration', color:'#00ff7a', title:'ETL job JOB-0088 completed',     body:'18,420 rows processed. Source: Money API → Redis Cache. Duration: 3m 04s.', ts:'14:20', read:true, link:'integration' },
  { id:'n008', cat:'ALERT',      service:'apex',        color:'#ffc400', title:'APEX degraded: avg confidence 0.78', body:'Below 0.80 threshold across 91 completed runs this session.', ts:'13:55', read:true, link:'apex' },
  { id:'n009', cat:'INSIGHT',    service:'bap',         color:'#FF6E00', title:'Q2 pipeline risk: 3 accounts',   body:'Martinez ($52K), TexOil ($189K), Gulf Coast ($8.9K) showing 60-day DSO breach signals.', ts:'13:45', read:true, link:'bap' },
  { id:'n010', cat:'SYSTEM',     service:'integration', color:'#8a9bb5', title:'JWT token refreshed',            body:'user_id: usr-0012 · scope: all-services · TTL: 3600s. Next refresh in 1 hour.', ts:'13:00', read:true, link:'integration' },
  { id:'n011', cat:'CONVERSION', service:'money',       color:'#22c55e', title:'Conversion: Bayou City Electric', body:'Revenue attributed: $14,200. Outreach to close: 7 days. Channel: Email.', ts:'12:30', read:true, link:'money' },
  { id:'n012', cat:'SYSTEM',     service:'cleardesk',   color:'#00d4aa', title:'Document auto-approved: INV-2025-0412', body:'Confidence 0.96 · $2,100 · Lone Star Contractors LLC. No escalation required.', ts:'12:10', read:true, link:'cleardesk' },
];

const CAT_COLORS = {
  ALERT:      { color:'#ef4444', bg:'rgba(239,68,68,0.1)',   border:'rgba(239,68,68,0.25)' },
  INSIGHT:    { color:'#FF6E00', bg:'rgba(255,110,0,0.1)',   border:'rgba(255,110,0,0.25)' },
  CONVERSION: { color:'#22c55e', bg:'rgba(34,197,94,0.1)',   border:'rgba(34,197,94,0.25)' },
  SYSTEM:     { color:'#8a9bb5', bg:'rgba(138,155,181,0.1)', border:'rgba(138,155,181,0.2)' },
};

const NotificationsScreen = ({ onNavigate }) => {
  const [notifs, setNotifs] = React.useState(NOTIF_DATA);
  const [filter, setFilter] = React.useState('ALL');

  React.useEffect(() => { lucide.createIcons(); });

  // Listen for new events from integration bus
  React.useEffect(() => {
    if(!window._reliantBus) return;
    const unsub = window._reliantBus.on('event', (evt) => {
      setNotifs(prev => [{
        id: `n-${Date.now()}`,
        cat: 'SYSTEM',
        service: evt.source,
        color: evt.color || '#00ff7a',
        title: evt.type,
        body: evt.payload,
        ts: new Date().toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false}),
        read: false,
        link: evt.source,
      }, ...prev].slice(0,50));
    });
    return unsub;
  }, []);

  const markAllRead = () => setNotifs(n=>n.map(x=>({...x,read:true})));
  const markRead = (id) => setNotifs(n=>n.map(x=>x.id===id?{...x,read:true}:x));

  const cats = ['ALL','ALERT','INSIGHT','CONVERSION','SYSTEM'];
  const filtered = filter==='ALL' ? notifs : notifs.filter(n=>n.cat===filter);
  const unread = notifs.filter(n=>!n.read).length;

  // Group by recency
  const today    = filtered.filter(n=>!['12:10','12:30','13:00'].includes(n.ts.split(' ')[0]) || parseInt(n.ts)>=12);
  const groups   = [
    { label:'Today', items: filtered.filter(n=>parseInt(n.ts)>=12) },
    { label:'Earlier', items: filtered.filter(n=>parseInt(n.ts)<12) },
  ].filter(g=>g.items.length>0);

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      {/* Header */}
      <div style={{padding:'20px 24px 14px',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:14}}>
          <div>
            <div style={{fontSize:11,color:'#8a9bb5',letterSpacing:'0.08em',textTransform:'uppercase',marginBottom:4,fontFamily:"'Inter',sans-serif"}}>Platform</div>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <div style={{fontSize:20,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif"}}>Notifications</div>
              {unread>0&&<div style={{background:'rgba(239,68,68,0.15)',color:'#ef4444',border:'1px solid rgba(239,68,68,0.3)',fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:8}}>{unread} unread</div>}
            </div>
          </div>
          {unread>0&&(
            <button onClick={markAllRead} style={{background:'rgba(255,110,0,0.08)',color:'#FF6E00',border:'1px solid rgba(255,110,0,0.25)',padding:'6px 12px',borderRadius:8,fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:"'Inter',sans-serif"}}>
              Mark all read
            </button>
          )}
        </div>
        {/* Category filters */}
        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
          {cats.map(c=>{
            const count = c==='ALL' ? notifs.filter(n=>!n.read).length : notifs.filter(n=>n.cat===c&&!n.read).length;
            const s = CAT_COLORS[c] || {};
            return (
              <div key={c} onClick={()=>setFilter(c)} style={{
                fontSize:10,fontWeight:600,padding:'4px 10px',borderRadius:8,cursor:'pointer',transition:'all 150ms',
                display:'flex',alignItems:'center',gap:5,
                background:filter===c?(s.bg||'rgba(255,110,0,0.1)'):'transparent',
                color:filter===c?(s.color||'#FF6E00'):'#8a9bb5',
                border:`1px solid ${filter===c?(s.border||'rgba(255,110,0,0.3)'):'#1c2b3c'}`,
                fontFamily:"'Inter',sans-serif",
              }}>
                {c}
                {count>0&&<span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'inherit',opacity:0.8}}>{count}</span>}
              </div>
            );
          })}
        </div>
      </div>

      {/* Feed */}
      <div style={{flex:1,overflowY:'auto'}}>
        {groups.map(group=>(
          <div key={group.label}>
            <div style={{padding:'12px 24px 6px',fontSize:10,color:'#4a5e75',textTransform:'uppercase',letterSpacing:'0.08em',fontFamily:"'Inter',sans-serif",fontWeight:600}}>{group.label}</div>
            {group.items.map((n,i)=>{
              const cs = CAT_COLORS[n.cat]||{color:'#8a9bb5',bg:'rgba(138,155,181,0.08)',border:'rgba(138,155,181,0.15)'};
              return (
                <div key={n.id} onClick={()=>{ markRead(n.id); onNavigate&&onNavigate(n.link); }}
                  style={{
                    display:'flex',gap:12,padding:'12px 24px',borderBottom:'1px solid #1c2b3c',cursor:'pointer',
                    background: n.read ? 'transparent' : 'rgba(255,110,0,0.02)',
                    transition:'background 150ms',
                  }}
                  onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,0.02)'}
                  onMouseLeave={e=>e.currentTarget.style.background=n.read?'transparent':'rgba(255,110,0,0.02)'}
                >
                  <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4,paddingTop:2,flexShrink:0}}>
                    <div style={{width:8,height:8,borderRadius:'50%',background: n.read ? '#1c2b3c' : n.color, boxShadow: n.read?'none':`0 0 5px ${n.color}70`}}/>
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:3,flexWrap:'wrap'}}>
                      <span style={{fontSize:9,fontWeight:700,padding:'2px 7px',borderRadius:6,background:cs.bg,color:cs.color,border:`1px solid ${cs.border}`,letterSpacing:'0.04em',fontFamily:"'Inter',sans-serif"}}>{n.cat}</span>
                      <span style={{fontSize:10,color:'#4a5e75',fontFamily:'IBM Plex Mono,monospace'}}>{n.service}</span>
                      {!n.read&&<div style={{width:5,height:5,borderRadius:'50%',background:'#FF6E00',marginLeft:'auto'}}/>}
                    </div>
                    <div style={{fontSize:12,fontWeight: n.read?400:600,color: n.read?'#8a9bb5':'#d4e4fa',marginBottom:3,lineHeight:1.4,fontFamily:"'Inter',sans-serif"}}>{n.title}</div>
                    <div style={{fontSize:11,color:'#4a5e75',lineHeight:1.5,fontFamily:"'Inter',sans-serif"}}>{n.body}</div>
                  </div>
                  <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75',flexShrink:0,paddingTop:2}}>{n.ts}</div>
                </div>
              );
            })}
          </div>
        ))}
        {filtered.length===0&&(
          <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:60,gap:12}}>
            <i data-lucide="bell" style={{width:32,height:32,color:'#1c2b3c'}}/>
            <div style={{fontSize:14,color:'#4a5e75',fontFamily:"'Inter',sans-serif"}}>No {filter!=='ALL'?filter.toLowerCase()+' ':' '}notifications.</div>
          </div>
        )}
      </div>
    </div>
  );
};

Object.assign(window, { NotificationsScreen });
