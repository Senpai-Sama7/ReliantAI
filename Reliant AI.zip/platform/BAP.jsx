// BAP.jsx — Business Analytics Platform

const BAP_CYAN = '#FF6E00';

const BAP_DATASETS = [
  { id:'DS-0041', name:'Q2_Revenue_Pipeline.csv',      rows:4821,  cols:18, size:'2.4 MB', status:'READY',      updated:'14:31', source:'HubSpot CRM',    insight:true  },
  { id:'DS-0040', name:'HVAC_Dispatch_History.parquet', rows:18420, cols:24, size:'8.1 MB', status:'READY',      updated:'14:20', source:'Money API',       insight:true  },
  { id:'DS-0039', name:'AR_Aging_Report_May.xlsx',      rows:892,   cols:12, size:'0.6 MB', status:'PROCESSING', updated:'14:10', source:'ClearDesk',       insight:false },
  { id:'DS-0038', name:'Customer_Cohort_Analysis.csv',  rows:2104,  cols:9,  size:'1.1 MB', status:'READY',      updated:'13:45', source:'PostgreSQL',      insight:true  },
  { id:'DS-0037', name:'Energy_Price_Forecast.json',    rows:365,   cols:6,  size:'0.2 MB', status:'READY',      updated:'12:00', source:'EIA API',         insight:false },
  { id:'DS-0036', name:'Technician_Utilization.csv',    rows:156,   cols:15, size:'0.4 MB', status:'FAILED',     updated:'11:30', source:'Money API',       insight:false },
];

const BAP_JOBS = [
  { id:'JOB-0089', name:'Revenue Pipeline ETL',    status:'RUNNING',   progress:67, started:'14:28', duration:'4m 12s', task_id:'a3f9-b82c', celery:'@worker-1', source:'HubSpot',    dest:'PostgreSQL' },
  { id:'JOB-0088', name:'Dispatch KPI Rollup',     status:'COMPLETED', progress:100,started:'14:20', duration:'3m 04s', task_id:'b81c-c22d', celery:'@worker-2', source:'Money API',   dest:'Redis Cache' },
  { id:'JOB-0087', name:'AR Aging Transform',      status:'RUNNING',   progress:34, started:'14:10', duration:'1m 58s', task_id:'c22d-d55e', celery:'@worker-1', source:'ClearDesk',   dest:'PostgreSQL' },
  { id:'JOB-0086', name:'Customer Cohort Build',   status:'COMPLETED', progress:100,started:'13:45', duration:'5m 42s', task_id:'d55e-e90f', celery:'@worker-3', source:'PostgreSQL',  dest:'S3' },
  { id:'JOB-0085', name:'Technician Util Extract', status:'FAILED',    progress:22, started:'11:30', duration:'0m 31s', task_id:'e90f-f12a', celery:'@worker-2', source:'Money API',   dest:'—' },
  { id:'JOB-0084', name:'Anomaly Detection Scan',  status:'QUEUED',    progress:0,  started:'—',     duration:'—',      task_id:'f12a-g34b', celery:'@worker-4', source:'All Sources', dest:'Insights' },
];

const BAP_INSIGHTS = [
  { id:'INS-0024', type:'ANOMALY',   confidence:0.87, title:'Dispatch surge — 96°F heat event', detail:'HVAC dispatch volume 340% above 30-day baseline. Revenue impact: +$18,400 projected.', service:'money',    color:'#ff3b5c',  ts:'14:31' },
  { id:'INS-0023', type:'TREND',     confidence:0.93, title:'Q2 pipeline at-risk: 3 accounts',   detail:'Martinez HVAC ($52K), TexOil ($189K), Gulf Coast ($8.9K) showing 60-day DSO breach signals.', service:'cleardesk', color:'#ffc400', ts:'14:20' },
  { id:'INS-0022', type:'FORECAST',  confidence:0.79, title:'July energy price spike forecast',   detail:'EIA model predicts +14% natural gas increase. Recommend HVAC contract pre-purchase window: May 15–30.', service:'bap', color:BAP_CYAN, ts:'13:55' },
  { id:'INS-0021', type:'ANOMALY',   confidence:0.91, title:'Technician utilization bottleneck', detail:'Rodriguez, M. at 118% capacity. Williams, T. and Davis, K. under-scheduled. Rebalancing recommended.', service:'money', color:'#ff3b5c', ts:'12:40' },
  { id:'INS-0020', type:'TREND',     confidence:0.85, title:'AR confidence improving',           detail:'Average confidence score up 0.06 over 14 days (0.85 → 0.91). Escalation rate down 18%.', service:'cleardesk', color:'#00d4aa', ts:'11:00' },
];

const DSStatus = ({s}) => {
  const map = { READY:{bg:'rgba(0,255,122,0.08)',color:'#00ff7a',border:'rgba(0,255,122,0.25)'}, PROCESSING:{bg:'rgba(255,110,0,0.08)',color:BAP_CYAN,border:'rgba(255,110,0,0.25)'}, FAILED:{bg:'rgba(255,59,92,0.08)',color:'#ff3b5c',border:'rgba(255,59,92,0.25)'}, COMPLETED:{bg:'rgba(0,255,122,0.08)',color:'#00ff7a',border:'rgba(0,255,122,0.25)'}, RUNNING:{bg:'rgba(255,196,0,0.08)',color:'#ffc400',border:'rgba(255,196,0,0.25)'}, QUEUED:{bg:'rgba(74,104,128,0.1)',color:'#8a9bb5',border:'rgba(74,104,128,0.2)'} };
  const st = map[s] || map.QUEUED;
  return <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:st.bg,color:st.color,border:`1px solid ${st.border}`,letterSpacing:'0.04em',whiteSpace:'nowrap'}}>{s}</span>;
};

const ProgressBar = ({val,color}) => (
  <div style={{display:'flex',alignItems:'center',gap:8}}>
    <div style={{width:72,height:4,background:'#1c2b3c',borderRadius:3,overflow:'hidden'}}>
      <div style={{width:`${val}%`,height:'100%',background:color||BAP_CYAN,transition:'width 300ms'}}/>
    </div>
    <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',minWidth:28}}>{val}%</span>
  </div>
);

// Mini sparkline SVG
const Sparkline = ({ data, color, width=80, height=24 }) => {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v,i) => {
    const x = (i / (data.length-1)) * width;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={width} height={height} style={{display:'block'}}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
      <circle cx={pts.split(' ').pop().split(',')[0]} cy={pts.split(' ').pop().split(',')[1]} r="2" fill={color}/>
    </svg>
  );
};

const ForecastChart = () => {
  const months = ['Nov','Dec','Jan','Feb','Mar','Apr','May','Jun','Jul'];
  const actual  = [41,48,52,39,55,61,null,null,null];
  const forecast= [null,null,null,null,null,61,68,74,70];
  const maxVal = 80;
  const barW = 32;
  const gap = 8;
  const chartH = 120;

  return (
    <div style={{padding:24,maxWidth:700}}>
      <div style={{fontSize:16,fontWeight:700,color:'#d4e4fa',marginBottom:4}}>Revenue Forecast</div>
      <div style={{fontSize:12,color:'#8a9bb5',marginBottom:20}}>Monthly dispatch revenue ($K) · actual + AI projection</div>
      <div style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'20px 20px 12px',display:'flex',flexDirection:'column',gap:12}}>
        <div style={{display:'flex',gap:gap,alignItems:'flex-end',height:chartH+20}}>
          {months.map((m,i) => {
            const val = actual[i] !== null ? actual[i] : forecast[i];
            const isForecast = actual[i] === null;
            const h = ((val||0)/maxVal)*chartH;
            return (
              <div key={m} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:isForecast?'#ffc400':'#d4e4fa'}}>{val||'—'}</span>
                <div style={{width:barW,height:h||4,background:isForecast?'rgba(255,196,0,0.25)':'rgba(255,110,0,0.25)',border:`1px solid ${isForecast?'rgba(255,196,0,0.5)':BAP_CYAN+'60'}`,borderBottom:'none',transition:'height 400ms'}}/>
                <span style={{fontSize:9,color:isForecast?'#ffc400':'#8a9bb5'}}>{m}</span>
              </div>
            );
          })}
        </div>
        <div style={{display:'flex',gap:16,paddingTop:4,borderTop:'1px solid #1c2b3c'}}>
          <div style={{display:'flex',gap:6,alignItems:'center'}}><div style={{width:12,height:4,background:BAP_CYAN+'60',border:`1px solid ${BAP_CYAN}60`}}/><span style={{fontSize:10,color:'#8a9bb5'}}>Actual</span></div>
          <div style={{display:'flex',gap:6,alignItems:'center'}}><div style={{width:12,height:4,background:'rgba(255,196,0,0.3)',border:'1px solid rgba(255,196,0,0.5)'}}/><span style={{fontSize:10,color:'#8a9bb5'}}>Forecast (conf 0.79)</span></div>
        </div>
      </div>
      <div style={{marginTop:16,display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
        {[['Projected Revenue (May)','$68K','#ffc400'],['YTD Revenue','$296K',BAP_CYAN],['Growth Rate','+13.1% MoM','#00ff7a']].map(([k,v,c])=>(
          <div key={k} style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'10px 14px'}}>
            <div style={{fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.07em',marginBottom:4}}>{k}</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:16,fontWeight:600,color:c}}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

const BAPScreen = ({ onToast }) => {
  const [tab, setTab] = React.useState('insights');

  React.useEffect(() => { lucide.createIcons(); });

  const TABS = ['insights','datasets','etl jobs','forecasting','trend','donut','heatmap'];

  const kpis = [
    {label:'Datasets',   val:'156',   color:'#d4e4fa'},
    {label:'ETL Jobs',   val:'8',     color:BAP_CYAN},
    {label:'AI Insights',val:'24',    color:'#ffc400'},
    {label:'Anomalies',  val:'4',     color:'#ff3b5c'},
    {label:'Rows Today', val:'28.4K', color:'#d4e4fa'},
  ];

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{padding:'16px 20px',borderBottom:'1px solid rgba(255,110,0,0.08)',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0,background:'linear-gradient(135deg, rgba(255,110,0,0.03) 0%, transparent 50%)'}}>
        <div>
          <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>Business Analytics Platform</div>
          <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>B-A-P</div>
        </div>
        <button onClick={()=>onToast&&onToast('ETL scan queued',BAP_CYAN)} style={{background:'rgba(255,110,0,0.1)',color:BAP_CYAN,border:`1px solid rgba(255,110,0,0.3)`,padding:'7px 14px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
          <i data-lucide="zap" style={{width:13,height:13}}/>Run Scan
        </button>
      </div>

      <div style={{display:'flex',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
        {kpis.map((k,i)=>(
          <div key={k.label} style={{flex:1,padding:'10px 16px',borderRight:i<kpis.length-1?'1px solid #1c2b3c':'none'}}>
            <div style={{fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:4}}>{k.label}</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:20,fontWeight:600,color:k.color}}>{k.val}</div>
          </div>
        ))}
      </div>

      <div style={{display:'flex',borderBottom:'1px solid #1c2b3c',padding:'0 20px',flexShrink:0}}>
        {TABS.map(t=>(
          <div key={t} onClick={()=>setTab(t)} style={{padding:'9px 16px',fontSize:12,cursor:'pointer',color:tab===t?'#d4e4fa':'#8a9bb5',borderBottom:tab===t?`2px solid ${BAP_CYAN}`:'2px solid transparent',transition:'all 150ms',textTransform:'capitalize',paddingLeft: t===TABS[0]?0:16}}>{t}</div>
        ))}
      </div>

      <div style={{flex:1,overflow:'auto'}}>
        {tab==='insights' && (
          <div style={{padding:20,display:'flex',flexDirection:'column',gap:10}}>
            {BAP_INSIGHTS.map(ins=>(
              <div key={ins.id} style={{background:'#0d1c2d',border:`1px solid ${ins.color}25`,borderLeft:`3px solid ${ins.color}`,boxShadow:`inset 0 0 30px ${ins.color}06, 2px 0 0 ${ins.color}20`,padding:'12px 16px',display:'flex',gap:16,alignItems:'flex-start'}}>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:4}}>
                    <span style={{fontSize:9,fontWeight:700,padding:'2px 7px',borderRadius:8,background:`rgba(${ins.color==='#ff3b5c'?'255,59,92':ins.color==='#ffc400'?'255,196,0':ins.color==='#00d4aa'?'0,212,170':'0,229,255'},0.1)`,color:ins.color,border:`1px solid ${ins.color}40`,letterSpacing:'0.04em'}}>{ins.type}</span>
                    <span style={{fontSize:9,color:'#8a9bb5',fontFamily:'IBM Plex Mono,monospace'}}>{ins.id}</span>
                    <span style={{fontSize:9,color:'#8a9bb5',fontFamily:'IBM Plex Mono,monospace'}}>source:{ins.service}</span>
                  </div>
                  <div style={{fontSize:13,fontWeight:500,color:'#d4e4fa',marginBottom:3}}>{ins.title}</div>
                  <div style={{fontSize:12,color:'#d4e4fa',lineHeight:1.5}}>{ins.detail}</div>
                </div>
                <div style={{flexShrink:0,textAlign:'right'}}>
                  <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:ins.confidence>=0.9?'#00ff7a':ins.confidence>=0.75?BAP_CYAN:'#ffc400',marginBottom:2}}>conf {ins.confidence.toFixed(2)}</div>
                  <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75'}}>{ins.ts}</div>
                </div>
              </div>
            ))}
          </div>
        )}
        {tab==='datasets' && (
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead><tr style={{background:'#122131',position:'sticky',top:0,zIndex:1}}>
              {['Dataset ID','Name','Source','Rows','Cols','Size','Status','Updated','Insights'].map(h=>(
                <th key={h} style={{padding:'7px 14px',textAlign:'left',fontSize:9,fontWeight:600,color:'#8a9bb5',letterSpacing:'0.07em',textTransform:'uppercase',borderBottom:'1px solid #273647',whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {BAP_DATASETS.map(d=>(
                <tr key={d.id} style={{borderBottom:'1px solid #1c2b3c',transition:'background 100ms'}}
                  onMouseEnter={e=>e.currentTarget.style.background='#122131'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:BAP_CYAN}}>{d.id}</td>
                  <td style={{padding:'8px 14px',fontSize:12,color:'#d4e4fa',maxWidth:200}}><div style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{d.name}</div></td>
                  <td style={{padding:'8px 14px',fontSize:11,color:'#8a9bb5'}}>{d.source}</td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#d4e4fa'}}>{d.rows.toLocaleString()}</td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5'}}>{d.cols}</td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5'}}>{d.size}</td>
                  <td style={{padding:'8px 14px'}}><DSStatus s={d.status}/></td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>{d.updated}</td>
                  <td style={{padding:'8px 14px'}}>{d.insight&&<span style={{fontSize:9,color:BAP_CYAN,background:'rgba(255,110,0,0.08)',border:'1px solid rgba(255,110,0,0.25)',padding:'2px 7px',borderRadius:8}}>AI</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab==='etl jobs' && (
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead><tr style={{background:'#122131',position:'sticky',top:0,zIndex:1}}>
              {['Job ID','Name','Source','Dest','Worker','Progress','Status','Started','Duration'].map(h=>(
                <th key={h} style={{padding:'7px 14px',textAlign:'left',fontSize:9,fontWeight:600,color:'#8a9bb5',letterSpacing:'0.07em',textTransform:'uppercase',borderBottom:'1px solid #273647',whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {BAP_JOBS.map(j=>(
                <tr key={j.id} style={{borderBottom:'1px solid #1c2b3c',transition:'background 100ms'}}
                  onMouseEnter={e=>e.currentTarget.style.background='#122131'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:BAP_CYAN}}>{j.id}</td>
                  <td style={{padding:'8px 14px',fontSize:12,color:'#d4e4fa',whiteSpace:'nowrap'}}>{j.name}</td>
                  <td style={{padding:'8px 14px',fontSize:11,color:'#8a9bb5'}}>{j.source}</td>
                  <td style={{padding:'8px 14px',fontSize:11,color:'#8a9bb5'}}>{j.dest}</td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#4a5e75'}}>{j.celery}</td>
                  <td style={{padding:'8px 14px'}}><ProgressBar val={j.progress} color={j.status==='FAILED'?'#ff3b5c':j.status==='COMPLETED'?'#00ff7a':BAP_CYAN}/></td>
                  <td style={{padding:'8px 14px'}}><DSStatus s={j.status}/></td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>{j.started}</td>
                  <td style={{padding:'8px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>{j.duration}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab==='forecasting' && <ForecastChart/>}
        {tab==='trend' && <TrendChart/>}
        {tab==='donut' && <DonutChart/>}
        {tab==='heatmap' && <HeatmapChart/>}
      </div>
    </div>
  );
};

// ── Line / Area Trend Chart ───────────────────────────────────
const TREND_30D = [42,38,51,46,60,55,68,72,58,64,70,76,65,80,73,88,82,91,78,86,95,90,98,84,102,96,108,115,105,118];
const TrendChart = () => {
  const W=560,H=160,PAD={t:20,r:20,b:32,l:44};
  const cW=W-PAD.l-PAD.r, cH=H-PAD.t-PAD.b;
  const max=Math.max(...TREND_30D), min=Math.min(...TREND_30D)-5;
  const pts = TREND_30D.map((v,i)=>({ x:PAD.l+(i/(TREND_30D.length-1))*cW, y:PAD.t+cH-((v-min)/(max-min))*cH }));
  const linePts = pts.map(p=>`${p.x},${p.y}`).join(' ');
  const areaPts = `${pts[0].x},${PAD.t+cH} ${linePts} ${pts[pts.length-1].x},${PAD.t+cH}`;
  const yTicks = [min, min+(max-min)/2, max].map(v=>Math.round(v));
  const today = pts[pts.length-1];
  return (
    <div style={{padding:24,maxWidth:700}}>
      <div style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:16,fontWeight:700,color:'#d4e4fa',marginBottom:4}}>30-Day Revenue Trend</div>
      <div style={{fontFamily:"'Inter',sans-serif",fontSize:12,color:'#8a9bb5',marginBottom:20}}>Daily dispatch revenue ($K) · trailing 30 days</div>
      <div style={{background:'#0d1c2d',border:'1px solid #1c2b3c',borderRadius:12,padding:'20px 16px 12px',overflowX:'auto'}}>
        <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',minWidth:300,display:'block'}}>
          <defs>
            <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FF6E00" stopOpacity="0.25"/>
              <stop offset="100%" stopColor="#FF6E00" stopOpacity="0.02"/>
            </linearGradient>
          </defs>
          {/* Grid lines */}
          {yTicks.map((v,i)=>{
            const y = PAD.t+cH-((v-min)/(max-min))*cH;
            return <React.Fragment key={i}>
              <line x1={PAD.l} y1={y} x2={W-PAD.r} y2={y} stroke="#1c2b3c" strokeWidth="1" strokeDasharray="4,4"/>
              <text x={PAD.l-6} y={y+4} textAnchor="end" fill="#4a5e75" fontSize="9" fontFamily="IBM Plex Mono">{v}</text>
            </React.Fragment>;
          })}
          {/* X axis labels every 5 days */}
          {[0,4,9,14,19,24,29].map(i=>(
            <text key={i} x={pts[i].x} y={H-4} textAnchor="middle" fill="#4a5e75" fontSize="9" fontFamily="IBM Plex Mono">d-{29-i}</text>
          ))}
          {/* Area fill */}
          <polygon points={areaPts} fill="url(#areaGrad)"/>
          {/* Line */}
          <polyline points={linePts} fill="none" stroke="#FF6E00" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round"/>
          {/* Today dot */}
          <circle cx={today.x} cy={today.y} r="5" fill="#FF6E00" stroke="#051424" strokeWidth="2"/>
          <text x={today.x} y={today.y-10} textAnchor="middle" fill="#FF6E00" fontSize="10" fontFamily="IBM Plex Mono" fontWeight="600">${TREND_30D[29]}K</text>
        </svg>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8,marginTop:12}}>
        {[['30d High','$118K','#22c55e'],['30d Low','$38K','#ef4444'],['Avg/Day','$78K','#FF6E00'],['Growth','+181%','#22c55e']].map(([k,v,c])=>(
          <div key={k} style={{background:'#0d1c2d',border:'1px solid #1c2b3c',borderRadius:10,padding:'10px 12px'}}>
            <div style={{fontFamily:"'Inter',sans-serif",fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.07em',marginBottom:4}}>{k}</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:16,fontWeight:600,color:c}}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ── Donut Chart ───────────────────────────────────────────────
const DONUT_DATA = [
  { label:'Money API',   value:38, color:'#ffc400' },
  { label:'ClearDesk',   value:24, color:'#00d4aa' },
  { label:'HubSpot CRM', value:18, color:'#FF6E00' },
  { label:'PostgreSQL',  value:12, color:'#60a5fa' },
  { label:'EIA API',     value:5,  color:'#7c5cfc' },
  { label:'Other',       value:3,  color:'#4a5e75' },
];
const DonutChart = () => {
  const [hov, setHov] = React.useState(null);
  const total = DONUT_DATA.reduce((s,d)=>s+d.value,0);
  const R=70, r=44, CX=100, CY=100;
  let cum=0;
  const slices = DONUT_DATA.map(d=>{
    const start = (cum/total)*2*Math.PI - Math.PI/2;
    cum += d.value;
    const end = (cum/total)*2*Math.PI - Math.PI/2;
    const large = (d.value/total)>0.5?1:0;
    const x1=CX+R*Math.cos(start), y1=CY+R*Math.sin(start);
    const x2=CX+R*Math.cos(end),   y2=CY+R*Math.sin(end);
    const ix1=CX+r*Math.cos(start),iy1=CY+r*Math.sin(start);
    const ix2=CX+r*Math.cos(end),  iy2=CY+r*Math.sin(end);
    const path=`M${x1},${y1} A${R},${R} 0 ${large},1 ${x2},${y2} L${ix2},${iy2} A${r},${r} 0 ${large},0 ${ix1},${iy1} Z`;
    return { ...d, path, pct:Math.round((d.value/total)*100) };
  });
  return (
    <div style={{padding:24,maxWidth:600}}>
      <div style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:16,fontWeight:700,color:'#d4e4fa',marginBottom:4}}>Dataset Source Distribution</div>
      <div style={{fontFamily:"'Inter',sans-serif",fontSize:12,color:'#8a9bb5',marginBottom:20}}>Percentage of total rows ingested by data source · trailing 30d</div>
      <div style={{background:'#0d1c2d',border:'1px solid #1c2b3c',borderRadius:12,padding:20,display:'flex',gap:24,alignItems:'center',flexWrap:'wrap'}}>
        <svg viewBox="0 0 200 200" style={{width:180,height:180,flexShrink:0}}>
          {slices.map((s,i)=>(
            <path key={i} d={s.path} fill={s.color}
              opacity={hov===null||hov===i?1:0.3}
              style={{cursor:'pointer',transition:'opacity 150ms'}}
              onMouseEnter={()=>setHov(i)} onMouseLeave={()=>setHov(null)}/>
          ))}
          <circle cx={CX} cy={CY} r={r-4} fill="#0d1c2d"/>
          {hov!==null ? (
            <>
              <text x={CX} y={CY-6} textAnchor="middle" fill={slices[hov].color} fontSize="16" fontFamily="IBM Plex Mono" fontWeight="700">{slices[hov].pct}%</text>
              <text x={CX} y={CY+10} textAnchor="middle" fill="#8a9bb5" fontSize="8" fontFamily="Inter">{slices[hov].label}</text>
            </>
          ) : (
            <>
              <text x={CX} y={CY-4} textAnchor="middle" fill="#d4e4fa" fontSize="13" fontFamily="IBM Plex Mono" fontWeight="600">{total}</text>
              <text x={CX} y={CY+10} textAnchor="middle" fill="#8a9bb5" fontSize="8" fontFamily="Inter">datasets</text>
            </>
          )}
        </svg>
        <div style={{display:'flex',flexDirection:'column',gap:8,flex:1,minWidth:160}}>
          {slices.map((s,i)=>(
            <div key={i} onMouseEnter={()=>setHov(i)} onMouseLeave={()=>setHov(null)}
              style={{display:'flex',alignItems:'center',gap:10,cursor:'default',opacity:hov===null||hov===i?1:0.4,transition:'opacity 150ms'}}>
              <div style={{width:10,height:10,borderRadius:3,background:s.color,flexShrink:0}}/>
              <div style={{flex:1,fontFamily:"'Inter',sans-serif",fontSize:12,color:'#d4e4fa'}}>{s.label}</div>
              <div style={{display:'flex',alignItems:'center',gap:6}}>
                <div style={{width:60,height:3,background:'#1c2b3c',borderRadius:2,overflow:'hidden'}}>
                  <div style={{width:`${s.pct}%`,height:'100%',background:s.color}}/>
                </div>
                <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:s.color,minWidth:28}}>{s.pct}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ── Heatmap Chart ─────────────────────────────────────────────
const HeatmapChart = () => {
  const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const HOURS = Array.from({length:24},(_,i)=>i);
  // Simulate dispatch activity: higher midday/afternoon on weekdays
  const data = DAYS.map((d,di)=>
    HOURS.map(h=>{
      const isWeekend = di>=5;
      const base = isWeekend ? 0.2 : 0.5;
      const peak = h>=9&&h<=17 ? (isWeekend?0.3:0.8) : h>=18&&h<=21 ? 0.5 : 0.1;
      return Math.max(0, Math.min(1, base*peak + Math.random()*0.2));
    })
  );
  const [hov, setHov] = React.useState(null);
  const cellW=18, cellH=16, gap=2;
  const maxVal=1;
  const colorForVal = v => {
    if(v<0.1) return '#122131';
    if(v<0.3) return 'rgba(255,110,0,0.2)';
    if(v<0.5) return 'rgba(255,110,0,0.45)';
    if(v<0.7) return 'rgba(255,110,0,0.7)';
    return '#FF6E00';
  };
  return (
    <div style={{padding:24}}>
      <div style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:16,fontWeight:700,color:'#d4e4fa',marginBottom:4}}>Hourly Dispatch Activity</div>
      <div style={{fontFamily:"'Inter',sans-serif",fontSize:12,color:'#8a9bb5',marginBottom:20}}>7-day × 24-hour activity heatmap · normalized dispatch volume</div>
      <div style={{background:'#0d1c2d',border:'1px solid #1c2b3c',borderRadius:12,padding:'20px',overflowX:'auto'}}>
        {/* Hour labels */}
        <div style={{display:'flex',gap:gap,marginBottom:6,paddingLeft:36}}>
          {HOURS.filter(h=>h%3===0).map(h=>(
            <div key={h} style={{width:(cellW+gap)*3-gap,fontFamily:'IBM Plex Mono,monospace',fontSize:8,color:'#4a5e75',textAlign:'center'}}>{h}:00</div>
          ))}
        </div>
        {data.map((row,di)=>(
          <div key={di} style={{display:'flex',alignItems:'center',gap:gap,marginBottom:gap}}>
            <div style={{width:32,fontFamily:"'Inter',sans-serif",fontSize:9,color:'#8a9bb5',textAlign:'right',paddingRight:6,flexShrink:0}}>{DAYS[di]}</div>
            {row.map((v,hi)=>(
              <div key={hi}
                onMouseEnter={()=>setHov({d:di,h:hi,v})}
                onMouseLeave={()=>setHov(null)}
                style={{width:cellW,height:cellH,borderRadius:3,background:colorForVal(v),cursor:'default',transition:'transform 100ms',transform:hov?.d===di&&hov?.h===hi?'scale(1.3)':'scale(1)',position:'relative',flexShrink:0}}
              />
            ))}
          </div>
        ))}
        {/* Legend */}
        <div style={{display:'flex',alignItems:'center',gap:8,marginTop:12,paddingLeft:36}}>
          <span style={{fontFamily:"'Inter',sans-serif",fontSize:9,color:'#4a5e75'}}>Low</span>
          {[0.1,0.3,0.5,0.7,1.0].map((v,i)=>(
            <div key={i} style={{width:14,height:10,borderRadius:2,background:colorForVal(v)}}/>
          ))}
          <span style={{fontFamily:"'Inter',sans-serif",fontSize:9,color:'#4a5e75'}}>High</span>
          {hov&&<span style={{marginLeft:12,fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#FF6E00'}}>{DAYS[hov.d]} {hov.h}:00 — {Math.round(hov.v*100)}% activity</span>}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { BAPScreen });
