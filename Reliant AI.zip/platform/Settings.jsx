// Settings.jsx — Settings, Billing, Admin

const SettingsScreen = ({ subscreen, onToast }) => {
  React.useEffect(() => { lucide.createIcons(); });

  if(subscreen === 'billing') return <BillingScreen onToast={onToast}/>;
  if(subscreen === 'admin')   return <AdminScreen   onToast={onToast}/>;
  return <SettingsMain onToast={onToast}/>;
};

const Section = ({ title, children }) => (
  <div style={{marginBottom:24}}>
    <div style={{fontSize:11,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",marginBottom:10,paddingBottom:8,borderBottom:'1px solid #1c2b3c',textTransform:'uppercase',letterSpacing:'0.06em'}}>{title}</div>
    {children}
  </div>
);

const Field = ({ label, value, type='text', mono, onToast }) => {
  const [val, setVal] = React.useState(value);
  const [saved, setSaved] = React.useState(false);
  const save = () => { setSaved(true); setTimeout(()=>setSaved(false),1500); onToast&&onToast('Settings saved','#FF6E00'); };
  return (
    <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:8}}>
      <div style={{minWidth:160,fontSize:12,color:'#8a9bb5'}}>{label}</div>
      <input value={val} onChange={e=>setVal(e.target.value)} type={type}
        style={{flex:1,background:'#122131',border:'1px solid #273647',color:'#d4e4fa',fontSize:12,padding:'6px 10px',borderRadius:8,outline:'none',fontFamily:mono?'IBM Plex Mono,monospace':'Inter,sans-serif'}}/>
      <button onClick={save} style={{background:saved?'rgba(255,110,0,0.1)':'#122131',color:saved?'#FF6E00':'#8a9bb5',border:'1px solid #273647',padding:'5px 12px',fontSize:11,borderRadius:8,cursor:'pointer',transition:'all 150ms',whiteSpace:'nowrap'}}>{saved?'Saved':'Save'}</button>
    </div>
  );
};

const ApiKeyRow = ({ name, key_, created, onToast }) => {
  const [revealed, setRevealed] = React.useState(false);
  return (
    <div style={{display:'flex',gap:12,alignItems:'center',padding:'8px 0',borderBottom:'1px solid #1c2b3c'}}>
      <div style={{flex:1}}><div style={{fontSize:12,color:'#d4e4fa',marginBottom:1}}>{name}</div><div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75'}}>{created}</div></div>
      <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5',letterSpacing:'0.08em'}}>{revealed?key_:'rk_live_••••••••••••••••'}</div>
      <div onClick={()=>setRevealed(r=>!r)} style={{cursor:'pointer',fontSize:10,color:'#8a9bb5',padding:'3px 8px',border:'1px solid #1c2b3c',borderRadius:8}}>{revealed?'Hide':'Reveal'}</div>
      <div onClick={()=>onToast&&onToast(`API key revoked: ${name}`,'#ff3b5c')} style={{cursor:'pointer',fontSize:10,color:'#ff3b5c',padding:'3px 8px',border:'1px solid rgba(255,59,92,0.2)',borderRadius:8}}>Revoke</div>
    </div>
  );
};

const SettingsMain = ({ onToast }) => (
  <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
    <div style={{padding:'16px 20px',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
      <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>Organization</div>
      <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>Settings</div>
    </div>
    <div style={{flex:1,overflow:'auto',padding:24,maxWidth:720}}>
      <Section title="Organization Profile">
        <Field label="Organization Name" value="ReliantAI" onToast={onToast}/>
        <Field label="Owner" value="Douglas Mitchell" onToast={onToast}/>
        <Field label="Location" value="Houston, TX" onToast={onToast}/>
        <Field label="Contact Email" value="douglas@reliantai.com" type="email" onToast={onToast}/>
      </Section>
      <Section title="API Keys">
        <ApiKeyRow name="Production — Kong Gateway" key_="rk_live_a3f9b81cc22dd55e" created="Created 2025-01-15" onToast={onToast}/>
        <ApiKeyRow name="ClearDesk Integration" key_="rk_live_b81cc22de90ff12a" created="Created 2025-02-08" onToast={onToast}/>
        <ApiKeyRow name="Money Dispatch API"    key_="rk_live_c22dd55ef90f1234" created="Created 2025-03-01" onToast={onToast}/>
        <button onClick={()=>onToast&&onToast('New API key generated','#FF6E00')} style={{marginTop:10,background:'rgba(255,110,0,0.08)',color:'#FF6E00',border:'1px solid rgba(255,110,0,0.25)',padding:'6px 14px',fontSize:11,borderRadius:8,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
          <i data-lucide="plus" style={{width:12,height:12}}/>Generate New Key
        </button>
      </Section>
      <Section title="Webhooks">
        <Field label="Webhook URL" value="https://hooks.reliantai.com/events" mono onToast={onToast}/>
        <Field label="Secret" value="whsec_a3f9b81c…" mono onToast={onToast}/>
        <div style={{display:'flex',gap:8,marginTop:4}}>
          {['dispatch.completed','document.processed','agent.hitl_required'].map(e=>(
            <div key={e} style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#FF6E00',background:'rgba(0,229,255,0.06)',border:'1px solid rgba(255,110,0,0.2)',padding:'3px 7px',borderRadius:8}}>{e}</div>
          ))}
        </div>
      </Section>
      <Section title="Integrations">
        {[['Twilio','SMS dispatch notifications','CONNECTED'],['HubSpot CRM','Lead sync for Money service','CONNECTED'],['Stripe','Billing and subscription','CONNECTED'],['Composio','APEX tool bus connector','PENDING']].map(([name,desc,status])=>(
          <div key={name} style={{display:'flex',alignItems:'center',gap:12,marginBottom:8,padding:'10px 14px',background:'#0d1c2d',border:'1px solid #1c2b3c'}}>
            <div style={{flex:1}}><div style={{fontSize:12,color:'#d4e4fa',marginBottom:1}}>{name}</div><div style={{fontSize:11,color:'#8a9bb5'}}>{desc}</div></div>
            <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:status==='CONNECTED'?'rgba(0,255,122,0.08)':'rgba(255,196,0,0.08)',color:status==='CONNECTED'?'#00ff7a':'#ffc400',border:`1px solid ${status==='CONNECTED'?'rgba(0,255,122,0.25)':'rgba(255,196,0,0.25)'}`}}>{status}</span>
          </div>
        ))}
      </Section>
    </div>
  </div>
);

const BillingScreen = ({ onToast }) => (
  <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
    <div style={{padding:'16px 20px',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
      <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>Subscription & Usage</div>
      <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>Billing</div>
    </div>
    <div style={{flex:1,overflow:'auto',padding:24,maxWidth:720}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:24}}>
        {[['Plan','Enterprise','#ffc400'],['Seats','12/25','#d4e4fa'],['API Calls (30d)','284,821','#FF6E00'],['Monthly Cost','$2,400/mo','#ffc400']].map(([k,v,c])=>(
          <div key={k} style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'14px 16px'}}>
            <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.07em',marginBottom:6}}>{k}</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:18,fontWeight:600,color:c}}>{v}</div>
          </div>
        ))}
      </div>
      <Section title="Invoice History">
        {[['INV-2025-004','April 2025','$2,400','PAID'],['INV-2025-003','March 2025','$2,400','PAID'],['INV-2025-002','February 2025','$1,800','PAID'],['INV-2025-001','January 2025','$1,800','PAID']].map(([id,month,amount,status])=>(
          <div key={id} style={{display:'flex',alignItems:'center',gap:12,padding:'9px 0',borderBottom:'1px solid #1c2b3c'}}>
            <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#ffc400',minWidth:120}}>{id}</span>
            <span style={{fontSize:12,color:'#d4e4fa',flex:1}}>{month}</span>
            <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#d4e4fa'}}>{amount}</span>
            <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:'rgba(0,255,122,0.08)',color:'#00ff7a',border:'1px solid rgba(0,255,122,0.25)'}}>{status}</span>
            <span onClick={()=>onToast&&onToast(`Downloading ${id}`,'#ffc400')} style={{fontSize:10,color:'#8a9bb5',cursor:'pointer',padding:'3px 8px',border:'1px solid #1c2b3c',borderRadius:8,display:'flex',alignItems:'center',gap:4}}><i data-lucide="download" style={{width:10,height:10}}/>PDF</span>
          </div>
        ))}
      </Section>
      <div style={{marginTop:8}}>
        <button onClick={()=>onToast&&onToast('Redirecting to Stripe customer portal','#ffc400')} style={{background:'rgba(255,196,0,0.1)',color:'#ffc400',border:'1px solid rgba(255,196,0,0.3)',padding:'8px 16px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer'}}>Manage Subscription →</button>
      </div>
    </div>
  </div>
);

const AdminScreen = ({ onToast }) => {
  const USERS = [
    { id:'usr-0012', name:'Douglas Mitchell', email:'douglas@reliantai.com', role:'admin',   status:'ACTIVE',  lastSeen:'14:32' },
    { id:'usr-0013', name:'Rachel Chen',      email:'r.chen@reliantai.com',  role:'manager', status:'ACTIVE',  lastSeen:'14:18' },
    { id:'usr-0014', name:'Sunita Patel',     email:'s.patel@reliantai.com', role:'analyst', status:'ACTIVE',  lastSeen:'13:55' },
    { id:'usr-0015', name:'Marcus Williams',  email:'m.williams@reliantai.com',role:'tech',  status:'IDLE',    lastSeen:'12:30' },
    { id:'usr-0016', name:'Kevin Davis',      email:'k.davis@reliantai.com', role:'tech',    status:'IDLE',    lastSeen:'11:45' },
    { id:'usr-0017', name:'Ana Martinez',     email:'a.martinez@reliantai.com',role:'viewer',status:'INACTIVE',lastSeen:'2d ago' },
  ];
  const roleColors = { admin:'#ff3b5c', manager:'#ffc400', analyst:'#FF6E00', tech:'#00ff7a', viewer:'#8a9bb5' };

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{padding:'16px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
        <div>
          <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>User Management</div>
          <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>Admin</div>
        </div>
        <button onClick={()=>onToast&&onToast('Invite link copied to clipboard','#FF6E00')} style={{background:'rgba(255,110,0,0.08)',color:'#FF6E00',border:'1px solid rgba(255,110,0,0.25)',padding:'7px 14px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
          <i data-lucide="user-plus" style={{width:13,height:13}}/>Invite User
        </button>
      </div>
      <div style={{flex:1,overflow:'auto'}}>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr style={{background:'#122131',position:'sticky',top:0,zIndex:1}}>
            {['User ID','Name','Email','Role','Status','Last Seen','Actions'].map(h=>(
              <th key={h} style={{padding:'7px 14px',textAlign:'left',fontSize:9,fontWeight:600,color:'#8a9bb5',letterSpacing:'0.07em',textTransform:'uppercase',borderBottom:'1px solid #273647',whiteSpace:'nowrap'}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {USERS.map(u=>(
              <tr key={u.id} style={{borderBottom:'1px solid #1c2b3c',transition:'background 100ms'}}
                onMouseEnter={e=>e.currentTarget.style.background='#122131'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{padding:'9px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>{u.id}</td>
                <td style={{padding:'9px 14px',fontSize:12,color:'#d4e4fa',whiteSpace:'nowrap'}}>{u.name}</td>
                <td style={{padding:'9px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5'}}>{u.email}</td>
                <td style={{padding:'9px 14px'}}><span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:`${roleColors[u.role]}15`,color:roleColors[u.role],border:`1px solid ${roleColors[u.role]}40`,letterSpacing:'0.04em'}}>{u.role}</span></td>
                <td style={{padding:'9px 14px'}}><div style={{display:'flex',alignItems:'center',gap:6}}><div style={{width:5,height:5,borderRadius:'50%',background:u.status==='ACTIVE'?'#00ff7a':u.status==='IDLE'?'#ffc400':'#4a5e75'}}/><span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>{u.status}</span></div></td>
                <td style={{padding:'9px 14px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#4a5e75'}}>{u.lastSeen}</td>
                <td style={{padding:'9px 14px'}}>
                  <div style={{display:'flex',gap:6}}>
                    <span onClick={()=>onToast&&onToast(`Editing ${u.name}`,'#FF6E00')} style={{fontSize:10,color:'#8a9bb5',cursor:'pointer',padding:'2px 8px',border:'1px solid #1c2b3c',borderRadius:8}}>Edit</span>
                    {u.role!=='admin'&&<span onClick={()=>onToast&&onToast(`${u.name} suspended`,'#ff3b5c')} style={{fontSize:10,color:'#ff3b5c',cursor:'pointer',padding:'2px 8px',border:'1px solid rgba(255,59,92,0.2)',borderRadius:8}}>Suspend</span>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

Object.assign(window, { SettingsScreen });
