// Sidebar.jsx — ReliantAI Unified Platform

const NAV_ITEMS = [
  { id:'overview',     icon:'layout-dashboard', label:'Overview',     accent:null },
  { id:'cleardesk',   icon:'file-text',         label:'ClearDesk',   accent:'#00d4aa' },
  { id:'money',       icon:'zap',               label:'Money',       accent:'#ffc400' },
  { id:'bap',         icon:'bar-chart-2',       label:'B-A-P',       accent:'#FF6E00' },
  { id:'apex',        icon:'cpu',               label:'APEX',        accent:'#7c5cfc' },
  { id:'integration', icon:'layers',            label:'Integration', accent:'#00ff7a' },
  { id:'notifications', icon:'bell',              label:'Notifications', accent:'#FF6E00' },
];

const BOTTOM_ITEMS = [
  { id:'settings', icon:'settings',    label:'Settings' },
  { id:'billing',  icon:'credit-card', label:'Billing'  },
  { id:'admin',    icon:'users',       label:'Admin'    },
];

const NavItem = ({ item, active, onNavigate, collapsed, badge }) => {
  const [hov, setHov] = React.useState(false);
  const accent = item.accent || '#FF6E00';
  return (
    <div
      onClick={() => onNavigate(item.id)}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      title={collapsed ? item.label : undefined}
      style={{
        display:'flex', alignItems:'center', gap:10,
        padding: collapsed ? '10px 0' : '9px 16px',
        justifyContent: collapsed ? 'center' : 'flex-start',
        cursor:'pointer',
        background: active ? `linear-gradient(90deg, ${accent}12 0%, transparent 100%)` : hov ? 'rgba(255,255,255,0.03)' : 'transparent',
        borderLeft: active ? `3px solid ${accent}` : '3px solid transparent',
        boxShadow: active ? `inset 0 0 20px ${accent}08` : 'none',
        color: active ? '#d4e4fa' : hov ? '#d4e4fa' : '#8a9bb5',
        transition:'all 150ms ease',
        userSelect:'none',
        position:'relative',
      }}
    >
      <i data-lucide={item.icon} style={{width:16,height:16,flexShrink:0,color: active ? accent : 'inherit'}}/>
      {!collapsed && <span style={{fontSize:13,fontWeight: active ? 600 : 400,flex:1,fontFamily:"'Inter',sans-serif"}}>{item.label}</span>}
      {badge > 0 && (
        <div style={{
          position: collapsed ? 'absolute' : 'static',
          top: collapsed ? 6 : undefined,
          right: collapsed ? 6 : undefined,
          minWidth:16,height:16,borderRadius:8,
          background:'#ff3b5c',color:'#d4e4fa',
          fontSize:9,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',
          padding:'0 3px',
        }}>{badge}</div>
      )}
    </div>
  );
};

const SidebarNav = ({ active, onNavigate, collapsed, badges = {} }) => {
  return (
    <div style={{
      width: collapsed ? 44 : 200,
      background:'linear-gradient(180deg, #0d1c2d 0%, #071018 100%)',borderRight:'1px solid rgba(255,110,0,0.08)',
      display:'flex',flexDirection:'column',
      height:'100%',flexShrink:0,
      transition:'width 300ms ease',overflow:'hidden',
    }}>
      {/* Logo */}
      <div style={{
        padding: collapsed ? '18px 0' : '18px 16px',
        display:'flex',alignItems:'center',justifyContent: collapsed ? 'center' : 'flex-start',
        gap:10,borderBottom:'1px solid #1c2b3c',flexShrink:0,
      }}>
        <svg width="20" height="26" viewBox="0 0 24 32" fill="none" style={{flexShrink:0}}>
          <rect x="2" y="2" width="3" height="28" fill="#FF6E00"/>
          <rect x="2" y="2" width="14" height="3" fill="#FF6E00"/>
          <rect x="2" y="14" width="12" height="3" fill="#FF6E00"/>
          <rect x="13" y="2" width="3" height="15" fill="#FF6E00"/>
          <polygon points="14,17 17,17 24,30 20,30" fill="#FF6E00"/>
        </svg>
        {!collapsed && <span style={{fontFamily:'Inter,sans-serif',fontSize:14,fontWeight:700,color:'#d4e4fa',letterSpacing:'-0.01em',whiteSpace:'nowrap'}}>ReliantAI</span>}
      </div>

      {/* Main nav */}
      <nav style={{flex:1,padding:'8px 0',overflowY:'auto',overflowX:'hidden'}}>
        {NAV_ITEMS.map(item => (
          <NavItem key={item.id} item={item} active={active===item.id}
            onNavigate={onNavigate} collapsed={collapsed} badge={badges[item.id]||0}/>
        ))}
      </nav>

      {/* Bottom nav */}
      <div style={{padding:'0 0 8px',flexShrink:0}}>
        <div style={{borderTop:'1px solid #1c2b3c',margin:'8px 0'}}/>
        {BOTTOM_ITEMS.map(item => (
          <NavItem key={item.id} item={item} active={active===item.id}
            onNavigate={onNavigate} collapsed={collapsed} badge={badges[item.id]||0}/>
        ))}
        <div style={{
          display:'flex',alignItems:'center',gap:10,
          padding: collapsed ? '10px 0' : '10px 16px',
          justifyContent: collapsed ? 'center' : 'flex-start',
          borderTop:'1px solid #1c2b3c',marginTop:4,
        }}>
          <div style={{
            width:28,height:28,background:'#122131',border:'1px solid #273647',
            borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',
            fontSize:12,fontWeight:700,color:'#FF6E00',flexShrink:0,
          }}>D</div>
          {!collapsed && (
            <div style={{minWidth:0}}>
              <div style={{fontSize:11,color:'#d4e4fa',fontWeight:600,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',fontFamily:"'Inter',sans-serif"}}>Douglas Mitchell</div>
              <div style={{fontSize:9,color:'#8a9bb5',fontFamily:'IBM Plex Mono,monospace',whiteSpace:'nowrap'}}>admin · Houston TX</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { SidebarNav });
