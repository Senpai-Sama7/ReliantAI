// Integration.jsx — Live Event Stream + Saga Tracker

const INT_GREEN = '#00ff7a';

const BASE_EVENTS = [
  { id:'evt-a3f9', type:'dispatch.completed',       source:'money',       ts:'14:32:07', payload:'dispatch_id: DSP-2025-8821, tech: Rodriguez, M.',       color:'#00ff7a' },
  { id:'evt-b81c', type:'document.processed',        source:'cleardesk',   ts:'14:31:54', payload:'doc_id: INV-2025-0441, confidence: 0.61',               color:'#00d4aa' },
  { id:'evt-c22d', type:'agent.hitl_required',       source:'apex',        ts:'14:31:41', payload:'wf_id: wf-a9c3-d812, stakes: HIGH',                    color:'#7c5cfc' },
  { id:'evt-d55e', type:'lead.created',              source:'money',       ts:'14:31:28', payload:'phone: +1713…, urgency: URGENT',                       color:'#ffc400' },
  { id:'evt-e90f', type:'analytics.recorded',        source:'bap',         ts:'14:31:15', payload:'dataset: Q2_Revenue_Pipeline.csv, rows: 4821',         color:'#FF6E00' },
  { id:'evt-f12a', type:'saga.completed',            source:'integration', ts:'14:30:59', payload:'saga_id: sg-0041, steps: 3/3',                         color:'#00ff7a' },
  { id:'evt-g34b', type:'document.escalated',        source:'cleardesk',   ts:'14:30:44', payload:'doc_id: INV-2025-0398, reason: confidence_low',        color:'#ff3b5c' },
  { id:'evt-h56c', type:'dispatch.requested',        source:'money',       ts:'14:30:31', payload:'urgency: LIFE_SAFETY, location: 4821 Westheimer',      color:'#ff3b5c' },
  { id:'evt-i78d', type:'agent.task.completed',      source:'apex',        ts:'14:30:18', payload:'agent: research_agent, confidence: 0.94',              color:'#7c5cfc' },
  { id:'evt-j90e', type:'user.auth',                 source:'auth',        ts:'14:30:05', payload:'user_id: usr-0012, role: admin, jwt: issued',           color:'#8a9bb5' },
  { id:'evt-k12f', type:'analytics.anomaly',         source:'bap',         ts:'14:29:52', payload:'insight_type: anomaly, confidence: 0.87',              color:'#FF6E00' },
  { id:'evt-l34g', type:'saga.started',              source:'integration', ts:'14:29:39', payload:'saga_id: sg-0042, service: money',                     color:'#00ff7a' },
  { id:'evt-m56h', type:'etl.job.completed',         source:'bap',         ts:'14:29:22', payload:'job_id: JOB-0088, rows: 18420, dest: redis_cache',     color:'#FF6E00' },
  { id:'evt-n78i', type:'document.approved',         source:'cleardesk',   ts:'14:28:54', payload:'doc_id: INV-2025-0412, auto_approved: true',           color:'#00d4aa' },
  { id:'evt-o90j', type:'dispatch.en_route',         source:'money',       ts:'14:28:41', payload:'dispatch_id: DSP-2025-8820, eta: 22min',               color:'#ffc400' },
];

const NEW_EVENT_POOL = [
  { type:'kong.request',           source:'integration', payload:'route: /cleardesk/api/v1/documents, status: 200, latency: 12ms', color:'#00ff7a' },
  { type:'redis.stream.publish',   source:'integration', payload:'stream: events:money, consumer_group: dispatch-workers',         color:'#00ff7a' },
  { type:'document.processing',    source:'cleardesk',   payload:'doc_id: INV-2025-0455, ocr: complete, confidence: 0.88',         color:'#00d4aa' },
  { type:'dispatch.sms.sent',      source:'money',       payload:'dispatch_id: DSP-2025-8819, customer: Linda Tran, status: sent', color:'#ffc400' },
  { type:'agent.layer.passed',     source:'apex',        payload:'wf_id: wf-c88d-e047, layer: L4, status: quality-review',        color:'#7c5cfc' },
  { type:'etl.job.progress',       source:'bap',         payload:'job_id: JOB-0089, progress: 67%, celery: @worker-1',            color:'#FF6E00' },
  { type:'saga.step.completed',    source:'integration', payload:'saga_id: sg-0042, step: 2/3, service: scheduler_agent',         color:'#00ff7a' },
  { type:'auth.token.refreshed',   source:'auth',        payload:'user_id: usr-0012, scope: all-services, ttl: 3600s',            color:'#8a9bb5' },
];

const SAGAS = [
  { id:'sg-0042', service:'money',       steps:['lead.intake','urgency.triage','tech.schedule'],   current:1, status:'RUNNING'   },
  { id:'sg-0041', service:'cleardesk',   steps:['doc.upload','ocr.extract','confidence.score'],    current:2, status:'COMPLETED' },
  { id:'sg-0040', service:'apex',        steps:['analyze','calibrate','dispatch'],                 current:0, status:'RUNNING'   },
  { id:'sg-0039', service:'integration', steps:['event.ingest','transform','publish'],             current:2, status:'COMPLETED' },
];

const IntegrationScreen = () => {
  const [events, setEvents] = React.useState(BASE_EVENTS);
  const [filter, setFilter] = React.useState('all');
  const [tab, setTab] = React.useState('stream');
  const [counter, setCounter] = React.useState(0);

  // Receive events from global bus
  React.useEffect(() => {
    if(!window._reliantBus) return;
    const unsub = window._reliantBus.on('event', (evt) => {
      const now = new Date();
      const ts = now.toLocaleTimeString('en-US', {hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'});
      const newEvt = {
        id:`evt-ext-${Date.now()}`,
        type: evt.type,
        source: evt.source,
        ts,
        payload: evt.payload,
        color: evt.color || '#FF6E00',
        fresh: true,
      };
      setEvents(prev => [newEvt, ...prev.slice(0,49)]);
    });
    return unsub;
  }, []);

  // Auto-generate events
  React.useEffect(() => {
    const id = setInterval(() => {
      const pool = NEW_EVENT_POOL;
      const evt = pool[Math.floor(Math.random() * pool.length)];
      const now = new Date();
      const ts = now.toLocaleTimeString('en-US', {hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'});
      setEvents(prev => [{
        id:`evt-auto-${Date.now()}`,
        type: evt.type,
        source: evt.source,
        ts,
        payload: evt.payload,
        color: evt.color,
        fresh: true,
      }, ...prev.slice(0,49)]);
      setCounter(c => c+1);
    }, 3800);
    return () => clearInterval(id);
  }, []);

  React.useEffect(() => { lucide.createIcons(); });

  const sources = ['all','cleardesk','money','apex','bap','integration','auth'];
  const filtered = filter==='all' ? events : events.filter(e=>e.source===filter);

  const sourceCounts = {};
  events.forEach(e => { sourceCounts[e.source] = (sourceCounts[e.source]||0)+1; });

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{padding:'16px 20px',borderBottom:'1px solid rgba(0,255,122,0.1)',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0,background:'linear-gradient(135deg, rgba(0,255,122,0.02) 0%, transparent 60%)'}}>
        <div>
          <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>Auth · Event Bus · API Gateway · Saga Orchestrator</div>
          <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>Integration Layer</div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <div style={{width:8,height:8,borderRadius:'50%',background:INT_GREEN,boxShadow:'0 0 12px #00ff7a90, 0 0 24px #00ff7a40',animation:'live-ring 2s ease infinite'}}/>
          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>LIVE · Redis Streams</span>
          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',background:'#122131',border:'1px solid #273647',padding:'2px 7px',borderRadius:8}}>{events.length} events</span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{display:'flex',borderBottom:'1px solid #1c2b3c',padding:'0 20px',flexShrink:0}}>
        {['stream','sagas','gateway','api calls'].map(t=>(
          <div key={t} onClick={()=>setTab(t)} style={{padding:'8px 16px',fontSize:12,cursor:'pointer',color:tab===t?'#d4e4fa':'#8a9bb5',borderBottom:tab===t?`2px solid ${INT_GREEN}`:'2px solid transparent',transition:'all 150ms',textTransform:'capitalize',paddingLeft:t==='stream'?0:16}}>{t==='gateway'?'API Gateway':t==='api calls'?'API Calls':t.charAt(0).toUpperCase()+t.slice(1)}</div>
        ))}
      </div>

      {tab==='stream' && (
        <>
          {/* Source counts + filter */}
          <div style={{display:'flex',gap:6,padding:'8px 20px',borderBottom:'1px solid #1c2b3c',flexShrink:0,flexWrap:'wrap',alignItems:'center'}}>
            {sources.map(s=>(
              <div key={s} onClick={()=>setFilter(s)} style={{
                fontSize:10,fontWeight:500,padding:'3px 8px',borderRadius:8,cursor:'pointer',
                background:filter===s?'rgba(0,255,122,0.08)':'transparent',
                color:filter===s?INT_GREEN:'#8a9bb5',
                border:`1px solid ${filter===s?'rgba(0,255,122,0.3)':'#1c2b3c'}`,
                transition:'all 150ms',display:'flex',alignItems:'center',gap:5,
              }}>
                {s}
                {sourceCounts[s] && <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75'}}>{sourceCounts[s]}</span>}
              </div>
            ))}
          </div>
          <div style={{flex:1,overflowY:'auto'}}>
            {filtered.map((evt,i)=>(
              <div key={evt.id} style={{
                display:'flex',alignItems:'flex-start',gap:12,
                padding:'8px 20px',borderBottom:'1px solid #1c2b3c',
                background: evt.fresh && i===0 ? 'rgba(255,110,0,0.04)' : 'transparent',boxShadow: evt.fresh && i===0 ? 'inset 3px 0 0 rgba(255,110,0,0.3)' : 'none',
                transition:'background 600ms',
              }}>
                <div style={{width:6,height:6,borderRadius:'50%',background:evt.color,marginTop:4,flexShrink:0,boxShadow:`0 0 4px ${evt.color}60`}}/>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:'flex',gap:10,marginBottom:2,alignItems:'baseline'}}>
                    <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:evt.color,fontWeight:500}}>{evt.type}</span>
                    <span style={{fontSize:10,color:'#8a9bb5',fontFamily:'IBM Plex Mono,monospace'}}>{evt.source}</span>
                  </div>
                  <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{evt.payload}</div>
                </div>
                <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#4a5e75',flexShrink:0}}>{evt.ts}</div>
                <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#1c2b3c',flexShrink:0}}>{evt.id}</div>
              </div>
            ))}
          </div>
        </>
      )}

      {tab==='sagas' && (
        <div style={{flex:1,overflow:'auto',padding:20}}>
          <div style={{fontSize:12,color:'#8a9bb5',marginBottom:16}}>Active and recently completed saga orchestrations.</div>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            {SAGAS.map(saga=>(
              <div key={saga.id} style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'12px 16px'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                  <div style={{display:'flex',gap:10,alignItems:'center'}}>
                    <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:INT_GREEN}}>{saga.id}</span>
                    <span style={{fontSize:10,color:'#8a9bb5'}}>service: <span style={{color:'#d4e4fa'}}>{saga.service}</span></span>
                  </div>
                  <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:saga.status==='RUNNING'?'rgba(0,255,122,0.08)':'rgba(74,104,128,0.1)',color:saga.status==='RUNNING'?INT_GREEN:'#8a9bb5',border:`1px solid ${saga.status==='RUNNING'?'rgba(0,255,122,0.25)':'#1c2b3c'}`}}>{saga.status}</span>
                </div>
                <div style={{display:'flex',gap:0}}>
                  {saga.steps.map((step,i)=>{
                    const done = i < saga.current || saga.status==='COMPLETED';
                    const active = i===saga.current && saga.status==='RUNNING';
                    const col = done?INT_GREEN:active?'#ffc400':'#4a5e75';
                    return (
                      <React.Fragment key={step}>
                        <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
                          <div style={{width:10,height:10,borderRadius:'50%',background:col,boxShadow:active?`0 0 6px ${col}80`:undefined}}/>
                          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:col,whiteSpace:'nowrap'}}>{step}</span>
                        </div>
                        {i<saga.steps.length-1&&<div style={{flex:1,height:1,background:done?INT_GREEN+'40':'#1c2b3c',marginTop:5,minWidth:20}}/>}
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab==='api calls' && <APICallLog/>}

      {tab==='api calls' && (
        <div style={{flex:1,overflow:'hidden',display:'flex',flexDirection:'column'}}><APICallLog/></div>
      )}

      {tab==='gateway' && (
        <div style={{flex:1,overflow:'auto',padding:20}}>
          <div style={{fontSize:12,color:'#8a9bb5',marginBottom:16}}>Kong API Gateway — upstream routes and health.</div>
          <div style={{display:'flex',flexDirection:'column',gap:6}}>
            {[
              ['/cleardesk',   'cleardesk-service:8001', '99.98%', '12ms',  'UP'],
              ['/money',       'money-service:8002',     '99.95%', '18ms',  'UP'],
              ['/bap',         'bap-service:8003',       '99.91%', '24ms',  'UP'],
              ['/apex',        'apex-service:8004',      '99.72%', '31ms',  'WARN'],
              ['/auth',        'auth-service:8005',      '100%',   '3ms',   'UP'],
              ['/integration', 'integration:8006',       '100%',   '1ms',   'UP'],
              ['/events',      'redis-streams:6379',     '100%',   '0.8ms', 'UP'],
            ].map(([route,upstream,uptime,latency,status])=>(
              <div key={route} style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'10px 16px',display:'flex',gap:16,alignItems:'center'}}>
                <div style={{width:6,height:6,borderRadius:'50%',background:status==='UP'?INT_GREEN:'#ffc400',flexShrink:0,boxShadow:`0 0 4px ${status==='UP'?INT_GREEN:'#ffc400'}60`}}/>
                <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:12,color:'#FF6E00',minWidth:120}}>{route}</span>
                <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',flex:1}}>{upstream}</span>
                {[['uptime',uptime],['latency',latency]].map(([k,v])=>(
                  <div key={k}><div style={{fontSize:9,color:'#8a9bb5',marginBottom:1}}>{k}</div><div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#d4e4fa'}}>{v}</div></div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

Object.assign(window, { IntegrationScreen });
