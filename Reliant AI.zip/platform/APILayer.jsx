// APILayer.jsx — Simulated Kong API Gateway Client
// Mimics real ReliantAI integration layer: JWT auth, Kong routing, Redis Streams

const KONG_BASE = 'https://kong.reliantai.internal';
const JWT_MOCK = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c3ItMDAxMiIsInJvbGUiOiJhZG1pbiIsInNjb3BlIjoiYWxsLXNlcnZpY2VzIiwiaWF0IjoxNzQ2MDAwMDAwLCJleHAiOjE3NDYwMDM2MDB9.sig';

const ROUTE_MAP = {
  'GET /cleardesk/api/v1/documents':    { service:'cleardesk', latencyMs:[12,48], status:200 },
  'GET /cleardesk/api/v1/stats':         { service:'cleardesk', latencyMs:[8,22],  status:200 },
  'POST /cleardesk/api/v1/documents':    { service:'cleardesk', latencyMs:[180,420],status:201 },
  'GET /money/api/v1/dispatches':        { service:'money',     latencyMs:[14,52], status:200 },
  'POST /money/api/v1/dispatches':       { service:'money',     latencyMs:[220,580],status:201 },
  'GET /money/api/v1/technicians':       { service:'money',     latencyMs:[9,28],  status:200 },
  'GET /bap/api/v1/datasets':            { service:'bap',       latencyMs:[18,64], status:200 },
  'GET /bap/api/v1/insights':            { service:'bap',       latencyMs:[24,90], status:200 },
  'POST /bap/api/v1/etl/run':            { service:'bap',       latencyMs:[80,200],status:202 },
  'GET /apex/api/v1/workflows':          { service:'apex',      latencyMs:[16,55], status:200 },
  'POST /apex/api/v1/workflows/decide':  { service:'apex',      latencyMs:[140,380],status:200 },
  'GET /apex/api/v1/agents':             { service:'apex',      latencyMs:[11,34], status:200 },
  'GET /integration/events':             { service:'integration',latencyMs:[2,8],  status:200 },
  'GET /integration/sagas':              { service:'integration',latencyMs:[6,18], status:200 },
  'GET /auth/api/v1/me':                 { service:'auth',      latencyMs:[3,10],  status:200 },
  'POST /auth/api/v1/token/refresh':     { service:'auth',      latencyMs:[12,28], status:200 },
};

// Global API call log
if (!window._apiLog) window._apiLog = [];
if (!window._apiListeners) window._apiListeners = [];

const notifyAPIListeners = () => {
  window._apiListeners.forEach(fn => fn([...window._apiLog]));
};

// Core API call simulator
const apiCall = (method, path, body=null) => {
  const key = `${method} ${path}`;
  const route = ROUTE_MAP[key] || { service:'unknown', latencyMs:[50,200], status:200 };
  const [minL, maxL] = route.latencyMs;
  const latency = Math.round(minL + Math.random()*(maxL-minL));
  const corrId = `corr-${Math.random().toString(36).substr(2,8)}`;
  const reqId  = `req-${Date.now().toString(36)}`;

  const entry = {
    id: reqId,
    method, path,
    service: route.service,
    status: route.status,
    latency,
    corrId,
    ts: new Date().toLocaleTimeString('en-US',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'}),
    pending: true,
    headers: { 'Authorization': `Bearer ${JWT_MOCK.slice(0,40)}…`, 'X-Kong-Request-ID': reqId, 'X-Correlation-ID': corrId },
  };

  window._apiLog = [entry, ...window._apiLog.slice(0, 99)];
  notifyAPIListeners();

  return new Promise(resolve => {
    setTimeout(() => {
      entry.pending = false;
      window._apiLog = window._apiLog.map(e => e.id===reqId ? {...e, pending:false} : e);
      notifyAPIListeners();

      // Emit to event bus
      window._reliantBus && window._reliantBus.emit('event', {
        type: `${route.service}.api.${method.toLowerCase()}`,
        source: 'integration',
        payload: `${method} ${path} → ${route.status} · ${latency}ms · corr: ${corrId.slice(0,12)}`,
        color: route.status >= 400 ? '#ef4444' : '#00ff7a',
      });

      resolve({ status: route.status, latency, corrId, data: null });
    }, latency);
  });
};

// React hook: subscribes to the API log
const useAPILog = () => {
  const [log, setLog] = React.useState([...window._apiLog]);
  React.useEffect(() => {
    const listener = (newLog) => setLog([...newLog]);
    window._apiListeners.push(listener);
    return () => { window._apiListeners = window._apiListeners.filter(f=>f!==listener); };
  }, []);
  return log;
};

// React hook: live-polling API endpoint
const useAPIData = (method, path, intervalMs=0) => {
  const [state, setState] = React.useState({ loading:true, latency:null, status:null, error:null, calls:0 });
  const call = React.useCallback(() => {
    apiCall(method, path).then(r => setState(s=>({...s, loading:false, latency:r.latency, status:r.status, calls:s.calls+1})));
  }, [method, path]);
  React.useEffect(() => {
    call();
    if(intervalMs>0) { const t=setInterval(call,intervalMs); return()=>clearInterval(t); }
  }, [call, intervalMs]);
  return state;
};

// Live API status bar shown in TopBar
const APIStatusBar = () => {
  const log = useAPILog();
  const recent = log.slice(0,5);
  const pending = log.filter(e=>e.pending).length;
  const avgLatency = log.filter(e=>!e.pending).slice(0,20).reduce((s,e)=>s+e.latency,0) / Math.max(1,Math.min(20,log.filter(e=>!e.pending).length));

  // Auto-fire some calls periodically
  React.useEffect(() => {
    const routes = Object.keys(ROUTE_MAP);
    const t = setInterval(() => {
      const [method, ...pathParts] = routes[Math.floor(Math.random()*routes.length)].split(' ');
      apiCall(method, pathParts.join(' '));
    }, 6000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{display:'flex',alignItems:'center',gap:8,padding:'0 12px',borderLeft:'1px solid #1c2b3c',height:'100%'}}>
      <div style={{display:'flex',alignItems:'center',gap:5}}>
        <div style={{width:6,height:6,borderRadius:'50%',background: pending>0?'#ffc400':'#00ff7a',boxShadow:`0 0 5px ${pending>0?'#ffc40080':'#00ff7a80'}`}}/>
        <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#8a9bb5',whiteSpace:'nowrap'}}>KONG</span>
      </div>
      {log.length>0 && (
        <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75',whiteSpace:'nowrap'}}>
          {Math.round(avgLatency)}ms avg · {log.length} calls
        </span>
      )}
      {pending>0 && <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#ffc400'}}>{pending} pending</span>}
    </div>
  );
};

// API Call Log panel (embedded in Integration screen)
const APICallLog = () => {
  const log = useAPILog();
  const [filter, setFilter] = React.useState('all');
  const services = ['all','cleardesk','money','bap','apex','integration','auth'];

  // Fire initial burst of calls on mount
  React.useEffect(() => {
    const calls = [
      ['GET','/cleardesk/api/v1/documents'],
      ['GET','/money/api/v1/dispatches'],
      ['GET','/bap/api/v1/insights'],
      ['GET','/apex/api/v1/workflows'],
      ['GET','/integration/events'],
      ['POST','/auth/api/v1/token/refresh'],
    ];
    calls.forEach(([m,p],i) => setTimeout(()=>apiCall(m,p), i*400));
  }, []);

  const filtered = filter==='all' ? log : log.filter(e=>e.service===filter);
  const serviceColor = { cleardesk:'#00d4aa', money:'#ffc400', bap:'#FF6E00', apex:'#7c5cfc', integration:'#00ff7a', auth:'#8a9bb5', unknown:'#4a5e75' };

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{padding:'8px 20px',display:'flex',gap:6,borderBottom:'1px solid #1c2b3c',flexShrink:0,flexWrap:'wrap',alignItems:'center'}}>
        {services.map(s=>(
          <div key={s} onClick={()=>setFilter(s)} style={{
            fontSize:10,fontWeight:500,padding:'3px 9px',borderRadius:8,cursor:'pointer',transition:'all 150ms',
            background:filter===s?'rgba(255,110,0,0.1)':'transparent',
            color:filter===s?'#FF6E00':'#8a9bb5',
            border:`1px solid ${filter===s?'rgba(255,110,0,0.3)':'#1c2b3c'}`,
          }}>{s}</div>
        ))}
        <button onClick={()=>{ const r=Object.keys(ROUTE_MAP)[Math.floor(Math.random()*Object.keys(ROUTE_MAP).length)]; const [m,...p]=r.split(' '); apiCall(m,p.join(' ')); }}
          style={{marginLeft:'auto',padding:'3px 10px',borderRadius:8,border:'1px solid rgba(255,110,0,0.3)',background:'rgba(255,110,0,0.08)',color:'#FF6E00',fontSize:10,fontWeight:600,cursor:'pointer',fontFamily:"'Inter',sans-serif"}}>
          Fire Call
        </button>
      </div>
      <div style={{flex:1,overflowY:'auto'}}>
        {filtered.length===0 && <div style={{padding:40,textAlign:'center',fontFamily:"'Inter',sans-serif",fontSize:12,color:'#4a5e75'}}>No API calls yet.</div>}
        {filtered.map((e,i)=>(
          <div key={e.id} style={{display:'flex',gap:10,padding:'8px 20px',borderBottom:'1px solid #1c2b3c',alignItems:'flex-start',
            background:e.pending?'rgba(255,196,0,0.02)':'transparent',transition:'background 300ms'}}>
            <div style={{flexShrink:0,display:'flex',flexDirection:'column',gap:3,alignItems:'center',marginTop:2}}>
              <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,fontWeight:700,padding:'2px 5px',borderRadius:4,
                background:e.method==='GET'?'rgba(0,255,122,0.08)':'rgba(255,110,0,0.08)',
                color:e.method==='GET'?'#00ff7a':'#FF6E00',border:`1px solid ${e.method==='GET'?'rgba(0,255,122,0.2)':'rgba(255,110,0,0.2)'}`}}>
                {e.method}
              </span>
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:'flex',gap:8,marginBottom:3,alignItems:'baseline',flexWrap:'wrap'}}>
                <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#d4e4fa',fontWeight:500}}>{e.path}</span>
                {!e.pending && <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:e.status<300?'#00ff7a':e.status<400?'#ffc400':'#ef4444'}}>{e.status}</span>}
                <span style={{fontSize:10,color:serviceColor[e.service]||'#8a9bb5',fontFamily:'IBM Plex Mono,monospace'}}>{e.service}</span>
              </div>
              <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                corr: {e.corrId} · {e.headers['Authorization'].slice(0,30)}…
              </div>
            </div>
            <div style={{flexShrink:0,textAlign:'right'}}>
              {e.pending
                ? <div style={{width:12,height:12,border:'2px solid #ffc400',borderTopColor:'transparent',borderRadius:'50%',animation:'spin 700ms linear infinite'}}/>
                : <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#4a5e75'}}>{e.latency}ms</span>
              }
              <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75',marginTop:2}}>{e.ts}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { APIStatusBar, APICallLog, useAPIData, useAPILog, apiCall });
