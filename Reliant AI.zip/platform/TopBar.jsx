// TopBar.jsx — ReliantAI Platform Top Bar

const TopBar = ({ onCommandK, notifications = [], onClearNotif, onNavigate }) => {
  const [clock, setClock] = React.useState('');
  const [notifOpen, setNotifOpen] = React.useState(false);

  React.useEffect(() => {
    const tick = () => {
      const now = new Date();
      setClock(now.toLocaleTimeString('en-US', { hour12:false, hour:'2-digit', minute:'2-digit', second:'2-digit' }));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const unread = notifications.filter(n => !n.read).length;

  return (
    <div style={{
      height:48, background:'rgba(5,20,36,0.85)', borderBottom:'1px solid rgba(255,110,0,0.08)', backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)',
      display:'flex', alignItems:'center', gap:8, padding:'0 16px', flexShrink:0,
    }}>
      {/* Command K */}
      <div onClick={onCommandK} style={{
        display:'flex', alignItems:'center', gap:8, flex:1, maxWidth:360,
        background:'rgba(18,33,49,0.8)', border:'1px solid rgba(255,110,0,0.12)', padding:'5px 10px',
        cursor:'pointer', borderRadius:8, transition:'border 150ms',
      }}
        onMouseEnter={e => e.currentTarget.style.borderColor='#273647'}
        onMouseLeave={e => e.currentTarget.style.borderColor='#1c2b3c'}
      >
        <i data-lucide="search" style={{width:12,height:12,color:'#8a9bb5'}}/>
        <span style={{fontSize:11,color:'#4a5e75',fontFamily:'Inter,sans-serif',flex:1}}>Search services, routes, data…</span>
        <div style={{display:'flex',gap:3}}>
          {['⌘','K'].map((k,i) => (
            <span key={i} style={{fontSize:9,color:'#4a5e75',background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'1px 4px',borderRadius:8,fontFamily:'IBM Plex Mono,monospace'}}>{k}</span>
          ))}
        </div>
      </div>

      <div style={{flex:1}}/>
      {typeof APIStatusBar !== 'undefined' && <APIStatusBar/>}

      {/* Live metrics strip */}
      <div style={{display:'flex',gap:16,alignItems:'center'}}>
        <MetricPill label="req/s" val={284} color="#FF6E00" />
        <MetricPill label="queue" val={12} color="#00ff7a" />
        <MetricPill label="sagas" val={3} color="#ffc400" />
      </div>

      <div style={{width:1,height:20,background:'#1c2b3c',margin:'0 4px'}}/>

      {/* Clock */}
      <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5',letterSpacing:'0.04em',minWidth:64}}>{clock}</span>

      <div style={{width:1,height:20,background:'#1c2b3c',margin:'0 4px'}}/>

      {/* Notifications */}
      <div style={{position:'relative'}}>
        <div onClick={() => setNotifOpen(o => !o)} style={{
          width:30,height:30,display:'flex',alignItems:'center',justifyContent:'center',
          cursor:'pointer',borderRadius:8,position:'relative',
          background: notifOpen ? '#122131' : 'transparent',
          transition:'background 150ms',
        }}>
          <i data-lucide="bell" style={{width:15,height:15,color: unread>0?'#d4e4fa':'#8a9bb5'}}/>
          {unread > 0 && (
            <div style={{
              position:'absolute',top:3,right:3,width:14,height:14,borderRadius:8,
              background:'#ff3b5c',fontSize:8,fontWeight:700,color:'#d4e4fa',
              display:'flex',alignItems:'center',justifyContent:'center',
            }}>{unread}</div>
          )}
        </div>

        {notifOpen && (
          <div style={{
            position:'absolute',top:36,right:0,width:320,
            background:'#122131',border:'1px solid #273647',zIndex:300,
            boxShadow:'0 8px 32px rgba(0,0,0,0.5)',
          }} onClick={e=>e.stopPropagation()}>
            <div style={{padding:'10px 14px',borderBottom:'1px solid #1c2b3c',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontSize:13,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif"}}>Notifications</span>
              {unread > 0 && (
                <span onClick={() => onClearNotif && onClearNotif()} style={{fontSize:10,color:'#FF6E00',cursor:'pointer'}}>Mark all read</span>
              )}
            </div>
            {notifications.length === 0 ? (
              <div style={{padding:'20px 14px',fontSize:12,color:'#8a9bb5'}}>No notifications.</div>
            ) : notifications.slice(0,8).map((n,i) => (
              <div key={i} onClick={() => { n.action && n.action(); setNotifOpen(false); }} style={{
                padding:'9px 14px',borderBottom:'1px solid #1c2b3c',cursor: n.action?'pointer':'default',
                background: n.read ? 'transparent' : 'rgba(0,229,255,0.02)',
                transition:'background 150ms',
              }}
                onMouseEnter={e=>{ if(n.action) e.currentTarget.style.background='rgba(255,255,255,0.02)'; }}
                onMouseLeave={e=>{ e.currentTarget.style.background=n.read?'transparent':'rgba(0,229,255,0.02)'; }}
              >
                <div style={{display:'flex',gap:8,alignItems:'flex-start'}}>
                  <div style={{width:6,height:6,borderRadius:'50%',background:n.color||'#8a9bb5',flexShrink:0,marginTop:4}}/>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:11,color: n.read?'#8a9bb5':'#d4e4fa',lineHeight:1.4,marginBottom:2}}>{n.message}</div>
                    <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75'}}>{n.ts} · {n.source}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Close panel on outside click */}
      {/* API status inline (imported from APILayer) */}
      {notifOpen && <div style={{position:'fixed',inset:0,zIndex:299}} onClick={()=>setNotifOpen(false)}/>}
    </div>
  );
};

const MetricPill = ({ label, val, color }) => {
  const [cur, setCur] = React.useState(val);
  React.useEffect(() => {
    const id = setInterval(() => {
      setCur(v => {
        const delta = Math.floor(Math.random() * 21) - 10;
        return Math.max(0, v + delta);
      });
    }, 3000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{display:'flex',alignItems:'baseline',gap:4}}>
      <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,fontWeight:600,color}}>{cur}</span>
      <span style={{fontSize:9,color:'#8a9bb5'}}>{label}</span>
    </div>
  );
};

// Toast system
const ToastContainer = ({ toasts }) => (
  <div style={{position:'fixed',bottom:20,left:'50%',transform:'translateX(-50%)',zIndex:500,display:'flex',flexDirection:'column',gap:6,alignItems:'center',pointerEvents:'none'}}>
    {toasts.map(t => (
      <div key={t.id} style={{
        background:'#122131',border:`1px solid ${t.color||'#273647'}`,
        padding:'8px 16px',borderRadius:8,fontSize:12,color:'#d4e4fa',
        display:'flex',alignItems:'center',gap:8,
        boxShadow:`0 0 12px ${(t.color||'#273647')}40`,
        animation:'toast-in 200ms ease',
        whiteSpace:'nowrap',
      }}>
        <div style={{width:6,height:6,borderRadius:'50%',background:t.color||'#FF6E00',flexShrink:0}}/>
        {t.message}
      </div>
    ))}
  </div>
);

Object.assign(window, { TopBar, ToastContainer });
