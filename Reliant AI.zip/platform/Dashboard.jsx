// Dashboard.jsx — Platform Command Center Overview

const METRIC_DEFS = [
  { key:'req',   label:'Kong req/s',         init:284,  unit:'req/s',  color:'#FF6E00', delta:30 },
  { key:'queue', label:'Redis queue depth',  init:12,   unit:'msgs',   color:'#00ff7a', delta:5  },
  { key:'kafka', label:'Kafka lag',          init:0,    unit:'msgs',   color:'#00ff7a', delta:2  },
  { key:'pg',    label:'PG connections',     init:38,   unit:'/100',   color:'#d4e4fa', delta:3  },
  { key:'auth',  label:'Auth tokens/min',    init:47,   unit:'/min',   color:'#d4e4fa', delta:8  },
  { key:'saga',  label:'Saga active',        init:3,    unit:'sagas',  color:'#ffc400', delta:1  },
];

const useLiveMetrics = () => {
  const [vals, setVals] = React.useState(() => {
    const m = {};
    METRIC_DEFS.forEach(d => { m[d.key] = d.init; });
    return m;
  });
  React.useEffect(() => {
    const id = setInterval(() => {
      setVals(prev => {
        const next = {...prev};
        METRIC_DEFS.forEach(d => {
          const delta = Math.floor(Math.random() * d.delta * 2) - d.delta;
          next[d.key] = Math.max(0, prev[d.key] + delta);
        });
        return next;
      });
    }, 3500);
    return () => clearInterval(id);
  }, []);
  return vals;
};

const MetricsStrip = () => {
  const vals = useLiveMetrics();
  return (
    <div style={{display:'flex',borderTop:'1px solid rgba(255,110,0,0.06)',borderBottom:'1px solid rgba(255,110,0,0.06)',background:'rgba(13,28,45,0.7)',flexShrink:0,backdropFilter:'blur(8px)'}}>
      {METRIC_DEFS.map((m,i) => (
        <div key={m.key} style={{flex:1,padding:'10px 16px',borderRight: i<METRIC_DEFS.length-1 ? '1px solid #1c2b3c' : 'none'}}>
          <div style={{fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.07em',marginBottom:3,whiteSpace:'nowrap'}}>{m.label}</div>
          <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:14,fontWeight:600,color:m.color,transition:'color 300ms'}}>
            {vals[m.key]}<span style={{fontSize:10,color:'#8a9bb5',marginLeft:3}}>{m.unit}</span>
          </div>
        </div>
      ))}
    </div>
  );
};

const ServiceCard = ({ service, accent, status, metric, metricLabel, sub1Label, sub1Val, sub1Color, sub2Label, sub2Val, onClick, alert }) => {
  const [hov, setHov] = React.useState(false);
  return (
    <div onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? '#122131' : '#0d1c2d',
        border: `1px solid ${hov ? accent+'50' : '#1c2b3c'}`,
        padding:16,cursor:'pointer',transition:'all 150ms ease',
        flex:1,minWidth:140,position:'relative',
      }}
    >
      {alert && <div style={{position:'absolute',top:8,right:8,width:6,height:6,borderRadius:'50%',background:'#ff3b5c',boxShadow:'0 0 6px #ff3b5c80'}}/>}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}}>
        <div>
          <div style={{fontSize:12,fontWeight:600,color:'#d4e4fa',marginBottom:2}}>{service}</div>
          <div style={{fontSize:9,color:'#8a9bb5',fontFamily:'IBM Plex Mono,monospace'}}>{metricLabel}</div>
        </div>
        <StatusBadge status={status}/>
      </div>
      <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:22,fontWeight:700,color:accent,marginBottom:4,lineHeight:1}}>{metric}</div>
      <div style={{borderTop:'1px solid #1c2b3c',paddingTop:8,display:'flex',flexDirection:'column',gap:3}}>
        <div style={{display:'flex',justifyContent:'space-between'}}>
          <span style={{fontSize:10,color:'#8a9bb5'}}>{sub1Label}</span>
          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:sub1Color||'#d4e4fa'}}>{sub1Val}</span>
        </div>
        <div style={{display:'flex',justifyContent:'space-between'}}>
          <span style={{fontSize:10,color:'#8a9bb5'}}>{sub2Label}</span>
          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#d4e4fa'}}>{sub2Val}</span>
        </div>
      </div>
    </div>
  );
};

const StatusBadge = ({ status }) => {
  const styles = {
    OPERATIONAL:{ bg:'rgba(0,255,122,0.08)', color:'#00ff7a', border:'rgba(0,255,122,0.25)' },
    DEGRADED:   { bg:'rgba(255,196,0,0.08)',  color:'#ffc400', border:'rgba(255,196,0,0.25)' },
    DOWN:       { bg:'rgba(255,59,92,0.08)',  color:'#ff3b5c', border:'rgba(255,59,92,0.25)' },
  };
  const s = styles[status] || styles.DEGRADED;
  return (
    <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:s.bg,color:s.color,border:`1px solid ${s.border}`,letterSpacing:'0.05em',whiteSpace:'nowrap'}}>{status}</span>
  );
};

const AlertBanner = ({ color, icon, title, detail, action, onAction }) => (
  <div style={{
    margin:'0 24px 12px',padding:'10px 14px',
    background:`rgba(${color},0.06)`,
    border:`1px solid rgba(${color},0.2)`,
    borderLeft:`3px solid rgb(${color})`,
    display:'flex',alignItems:'flex-start',gap:10,
  }}>
    <i data-lucide={icon} style={{width:14,height:14,color:`rgb(${color})`,marginTop:1,flexShrink:0}}/>
    <div style={{flex:1,minWidth:0}}>
      <div style={{fontSize:11,fontWeight:600,color:`rgb(${color})`,marginBottom:2}}>{title}</div>
      <div style={{fontSize:12,color:'#d4e4fa'}}>{detail}</div>
    </div>
    {action && (
      <span onClick={onAction} style={{fontSize:11,color:'#FF6E00',cursor:'pointer',flexShrink:0,whiteSpace:'nowrap'}}>{action} →</span>
    )}
  </div>
);

const PlatformDashboard = ({ onNavigate }) => {
  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'auto'}}>
      <div style={{padding:'20px 24px 16px',borderBottom:'1px solid rgba(255,110,0,0.08)',flexShrink:0,background:'linear-gradient(135deg, rgba(255,110,0,0.03) 0%, transparent 60%)'}}>
        <div style={{fontSize:11,color:'#8a9bb5',letterSpacing:'0.08em',textTransform:'uppercase',marginBottom:4}}>Platform</div>
        <div style={{fontSize:20,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>Command Center</div>
      </div>

      <MetricsStrip/>

      <div style={{padding:'20px 24px 4px',display:'flex',gap:8,flexWrap:'wrap',flexShrink:0}}>
        <ServiceCard service="ClearDesk" accent="#00d4aa" status="OPERATIONAL"
          metric="1,284" metricLabel="docs processed today"
          sub1Label="Escalated" sub1Val="12" sub1Color="#ff3b5c"
          sub2Label="Avg confidence" sub2Val="0.91"
          onClick={() => onNavigate('cleardesk')}/>
        <ServiceCard service="Money" accent="#ffc400" status="OPERATIONAL"
          metric="47" metricLabel="dispatches today"
          sub1Label="Pending" sub1Val="3" sub1Color="#ffc400"
          sub2Label="Completed" sub2Val="44" alert={true}
          onClick={() => onNavigate('money')}/>
        <ServiceCard service="B-A-P" accent="#FF6E00" status="OPERATIONAL"
          metric="8" metricLabel="active ETL jobs"
          sub1Label="AI insights" sub1Val="24"
          sub2Label="Datasets" sub2Val="156"
          onClick={() => onNavigate('bap')}/>
        <ServiceCard service="APEX" accent="#7c5cfc" status="DEGRADED"
          metric="2" metricLabel="HITL pending"
          sub1Label="Completed runs" sub1Val="91" sub1Color="#00ff7a"
          sub2Label="Avg confidence" sub2Val="0.78" alert={true}
          onClick={() => onNavigate('apex')}/>
        <ServiceCard service="Integration" accent="#00ff7a" status="OPERATIONAL"
          metric="99.97%" metricLabel="uptime · 30d"
          sub1Label="Events/hr" sub1Val="2,840"
          sub2Label="Active sagas" sub2Val="3"
          onClick={() => onNavigate('integration')}/>
      </div>

      <div style={{padding:'4px 0',flexShrink:0}}>
        <AlertBanner color="255,59,92" icon="alert-triangle"
          title="LIFE_SAFETY — 911 Escalated · Owner Notified"
          detail="DSP-2025-8821 · Maria Sanchez · 4821 Westheimer Rd · Rodriguez, M. en route · 8 min ETA"
          action="View Dispatch" onAction={() => onNavigate('money')}/>
        <AlertBanner color="124,92,252" icon="cpu"
          title="APEX — HITL Decision Required"
          detail={<span>Workflow <span style={{fontFamily:'IBM Plex Mono,monospace',color:'#7c5cfc'}}>wf-a9c3-d812</span> · confidence: <span style={{fontFamily:'IBM Plex Mono,monospace'}}>0.63</span> · Stakes: HIGH</span>}
          action="Review" onAction={() => onNavigate('apex')}/>
      </div>

      <SystemHealthGrid/>
    </div>
  );
};

const SystemHealthGrid = () => {
  const services = [
    { name:'Kong API Gateway',   status:'UP',      latency:'12ms',  uptime:'99.98%', color:'#00ff7a' },
    { name:'Redis Streams',      status:'UP',      latency:'1ms',   uptime:'100%',   color:'#00ff7a' },
    { name:'PostgreSQL',         status:'UP',      latency:'4ms',   uptime:'99.99%', color:'#00ff7a' },
    { name:'Kafka',              status:'UP',      latency:'8ms',   uptime:'99.97%', color:'#00ff7a' },
    { name:'JWT Auth',           status:'UP',      latency:'3ms',   uptime:'100%',   color:'#00ff7a' },
    { name:'Saga Orchestrator',  status:'WARN',    latency:'24ms',  uptime:'99.82%', color:'#ffc400' },
    { name:'Prometheus/Grafana', status:'UP',      latency:'6ms',   uptime:'99.95%', color:'#00ff7a' },
    { name:'Celery Workers',     status:'UP',      latency:'—',     uptime:'99.91%', color:'#00ff7a' },
  ];
  return (
    <div style={{padding:'0 24px 24px',flexShrink:0}}>
      <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:10,marginTop:4}}>System Health</div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:6}}>
        {services.map(s => (
          <div key={s.name} style={{background:'rgba(13,28,45,0.8)',border:'1px solid #1c2b3c',padding:'8px 12px',display:'flex',alignItems:'center',gap:8,transition:'border 150ms ease'}}>
            <div style={{width:6,height:6,borderRadius:'50%',background:s.color,flexShrink:0,boxShadow:`0 0 4px ${s.color}60`}}/>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:10,color:'#d4e4fa',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{s.name}</div>
              <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#8a9bb5'}}>{s.latency} · {s.uptime}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { PlatformDashboard });
