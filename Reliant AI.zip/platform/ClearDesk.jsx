// ClearDesk.jsx — Document Processing

const CD_TEAL = '#00d4aa';

const CD_DOCS = [
  { id:'INV-2025-0441', filename:'MartinezHVAC_Invoice_0441.pdf',  type:'INVOICE',  priority:'CRITICAL', status:'ESCALATED',  customer:'Martinez HVAC Supply Co.',   amount:52400,  dueDate:'2025-05-01', confidence:0.61, assignee:'Chen, R.',  escalation:'Confidence below threshold · Amount exceeds $50K auto-approval limit' },
  { id:'INV-2025-0398', filename:'GulfCoast_Invoice_0398.pdf',     type:'INVOICE',  priority:'HIGH',     status:'PROCESSING', customer:'Gulf Coast Medical Group',    amount:8900,   dueDate:'2025-05-08', confidence:0.78, assignee:'Patel, S.', escalation:null },
  { id:'INV-2025-0412', filename:'LoneStar_Invoice_0412.pdf',      type:'INVOICE',  priority:'MEDIUM',   status:'COMPLETED',  customer:'Lone Star Contractors LLC',   amount:2100,   dueDate:'2025-05-15', confidence:0.96, assignee:null, escalation:null },
  { id:'PO-2025-0089',  filename:'Bayou_PO_0089.pdf',             type:'PO',       priority:'HIGH',     status:'PENDING',    customer:'Bayou City Enterprises',      amount:14200,  dueDate:'2025-05-03', confidence:0.83, assignee:'Chen, R.', escalation:null },
  { id:'CON-2025-0021', filename:'TexOil_Contract_0021.pdf',      type:'CONTRACT', priority:'CRITICAL', status:'ESCALATED',  customer:'TexOil Services Inc.',        amount:189000, dueDate:'2025-04-30', confidence:0.55, assignee:'Patel, S.', escalation:'High-value contract · Legal review required' },
  { id:'INV-2025-0423', filename:'Houston_Medical_0423.pdf',      type:'INVOICE',  priority:'LOW',      status:'COMPLETED',  customer:'Houston Medical Supply',      amount:890,    dueDate:'2025-05-22', confidence:0.99, assignee:null, escalation:null },
  { id:'INV-2025-0455', filename:'Reliant_Parts_0455.pdf',        type:'INVOICE',  priority:'MEDIUM',   status:'PENDING',    customer:'Reliant Parts & Supply',      amount:3400,   dueDate:'2025-05-18', confidence:0.88, assignee:null, escalation:null },
  { id:'PO-2025-0091',  filename:'TexMex_Construction_0091.pdf',  type:'PO',       priority:'HIGH',     status:'PROCESSING', customer:'TexMex Construction Group',   amount:21000,  dueDate:'2025-05-06', confidence:0.73, assignee:'Chen, R.', escalation:null },
];

const CD_PRIORITY = { CRITICAL:{bg:'rgba(255,59,92,0.1)',color:'#ff3b5c',border:'rgba(255,59,92,0.3)'}, HIGH:{bg:'rgba(255,140,0,0.1)',color:'#ff8c00',border:'rgba(255,140,0,0.25)'}, MEDIUM:{bg:'rgba(255,196,0,0.08)',color:'#ffc400',border:'rgba(255,196,0,0.25)'}, LOW:{bg:'rgba(74,104,128,0.1)',color:'#8a9bb5',border:'rgba(74,104,128,0.2)'} };
const CD_STATUS  = { ESCALATED:{bg:'rgba(255,59,92,0.1)',color:'#ff3b5c',border:'rgba(255,59,92,0.25)'}, PROCESSING:{bg:'rgba(255,110,0,0.08)',color:'#FF6E00',border:'rgba(255,110,0,0.25)'}, COMPLETED:{bg:'rgba(0,255,122,0.08)',color:'#00ff7a',border:'rgba(0,255,122,0.25)'}, PENDING:{bg:'rgba(255,196,0,0.08)',color:'#ffc400',border:'rgba(255,196,0,0.25)'} };

const CDBadge = ({label, s}) => (
  <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:8,background:s.bg,color:s.color,border:`1px solid ${s.border}`,letterSpacing:'0.04em',whiteSpace:'nowrap'}}>{label}</span>
);

const ConfBar = ({val}) => {
  const color = val >= 0.9 ? CD_TEAL : val >= 0.7 ? '#ffc400' : '#ff3b5c';
  return (
    <div style={{display:'flex',alignItems:'center',gap:6}}>
      <div style={{width:52,height:4,background:'#1c2b3c',borderRadius:3,overflow:'hidden'}}>
        <div style={{width:`${val*100}%`,height:'100%',background:color,transition:'width 300ms'}}/>
      </div>
      <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color,minWidth:28}}>{val.toFixed(2)}</span>
    </div>
  );
};

const CDDocDetail = ({ doc, onClose, onToast }) => {
  const [statusSel, setStatusSel] = React.useState(doc.status);
  const [saving, setSaving] = React.useState(false);

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => { setSaving(false); onToast('Status updated · ' + doc.id, CD_TEAL); onClose(); }, 900);
  };

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(1,10,25,0.88)',backdropFilter:'blur(12px)',WebkitBackdropFilter:'blur(12px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'rgba(18,33,49,0.95)',border:'1px solid rgba(255,110,0,0.15)',boxShadow:'0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(255,110,0,0.05)',width:600,maxHeight:'88vh',overflow:'auto',borderRadius:8}} onClick={e=>e.stopPropagation()}>
        <div style={{padding:'14px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',justifyContent:'space-between',alignItems:'flex-start',position:'sticky',top:0,background:'#122131',zIndex:1}}>
          <div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',marginBottom:3}}>{doc.id}</div>
            <div style={{fontSize:15,fontWeight:600,color:'#d4e4fa',marginBottom:6}}>{doc.filename}</div>
            <div style={{display:'flex',gap:6}}><CDBadge label={doc.priority} s={CD_PRIORITY[doc.priority]}/><CDBadge label={doc.status} s={CD_STATUS[doc.status]}/><span style={{fontSize:9,color:'#8a9bb5',padding:'2px 7px',border:'1px solid #1c2b3c',borderRadius:8}}>{doc.type}</span></div>
          </div>
          <div onClick={onClose} style={{cursor:'pointer',padding:4,color:'#8a9bb5'}}><i data-lucide="x" style={{width:15,height:15}}/></div>
        </div>
        <div style={{padding:'14px 20px',borderBottom:'1px solid #1c2b3c'}}>
          <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:10}}>Extracted Data</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px 20px'}}>
            {[['Customer',doc.customer],['Document ID',doc.id],['Amount',`$${doc.amount.toLocaleString()}`],['Due Date',doc.dueDate],['Assignee',doc.assignee||'Unassigned'],['Type',doc.type]].map(([k,v])=>(
              <div key={k}><div style={{fontSize:10,color:'#8a9bb5',marginBottom:2}}>{k}</div><div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:12,color:'#d4e4fa'}}>{v}</div></div>
            ))}
          </div>
        </div>
        <div style={{padding:'12px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',alignItems:'center',gap:20}}>
          <div><div style={{fontSize:10,color:'#8a9bb5',marginBottom:4}}>Confidence Score</div><ConfBar val={doc.confidence}/></div>
          {doc.confidence < 0.7 && <div style={{fontSize:11,color:'#ff3b5c',background:'rgba(255,59,92,0.06)',border:'1px solid rgba(255,59,92,0.2)',padding:'4px 10px',borderRadius:8}}>Below 0.70 threshold — manual review required</div>}
        </div>
        {doc.escalation && (
          <div style={{padding:'12px 20px',borderBottom:'1px solid #1c2b3c'}}>
            <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:8}}>Escalation Reasons</div>
            <div style={{padding:'8px 12px',background:'rgba(255,59,92,0.06)',border:'1px solid rgba(255,59,92,0.2)',borderLeft:'3px solid #ff3b5c',fontSize:12,color:'#ff3b5c'}}>{doc.escalation}</div>
          </div>
        )}
        <div style={{padding:'12px 20px',borderBottom:'1px solid #1c2b3c',display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div><div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:6}}>Summary (EN)</div><div style={{fontSize:12,color:'#d4e4fa',lineHeight:1.6}}>Invoice from {doc.customer} for ${doc.amount.toLocaleString()} due {doc.dueDate}. Standard NET-30 terms. Requires approval from finance manager.</div></div>
          <div><div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:6}}>Resumen (ES)</div><div style={{fontSize:12,color:'#d4e4fa',lineHeight:1.6}}>Factura de {doc.customer} por ${doc.amount.toLocaleString()} con vencimiento {doc.dueDate}. Términos NET-30. Requiere aprobación del gerente financiero.</div></div>
        </div>
        <div style={{padding:'12px 20px',display:'flex',gap:8,alignItems:'center'}}>
          <select value={statusSel} onChange={e=>setStatusSel(e.target.value)}
            style={{background:'#0d1c2d',border:'1px solid #273647',color:'#d4e4fa',padding:'6px 10px',borderRadius:8,fontSize:12,fontFamily:'Inter,sans-serif',outline:'none'}}>
            {['PENDING','PROCESSING','COMPLETED','ESCALATED'].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
          <button onClick={handleSave} disabled={saving}
            style={{background:CD_TEAL,color:'#051424',border:'none',padding:'7px 16px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer',opacity:saving?0.7:1}}>
            {saving ? 'Saving…' : 'Save Status'}
          </button>
          <button style={{background:'transparent',color:'#d4e4fa',border:'1px solid #273647',padding:'7px 14px',fontSize:12,borderRadius:8,cursor:'pointer'}}>Export</button>
        </div>
      </div>
    </div>
  );
};

const CDUploadModal = ({ onClose, onToast }) => {
  const [phase, setPhase] = React.useState('idle'); // idle | processing | done
  const [drag, setDrag] = React.useState(false);

  const handleDrop = () => {
    setPhase('processing');
    setTimeout(() => setPhase('done'), 2200);
  };

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(1,10,25,0.88)',backdropFilter:'blur(12px)',WebkitBackdropFilter:'blur(12px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'rgba(18,33,49,0.95)',border:'1px solid rgba(255,110,0,0.15)',boxShadow:'0 20px 60px rgba(0,0,0,0.6)',width:480,borderRadius:8}} onClick={e=>e.stopPropagation()}>
        <div style={{padding:'14px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div style={{fontSize:14,fontWeight:600,color:'#d4e4fa'}}>Upload Document</div>
          <div onClick={onClose} style={{cursor:'pointer',color:'#8a9bb5'}}><i data-lucide="x" style={{width:15,height:15}}/></div>
        </div>
        <div style={{padding:20}}>
          {phase === 'idle' && (
            <div onMouseEnter={()=>setDrag(true)} onMouseLeave={()=>setDrag(false)} onClick={handleDrop}
              style={{border:`2px dashed ${drag?CD_TEAL:'#273647'}`,padding:'40px 20px',textAlign:'center',cursor:'pointer',transition:'border 150ms',borderRadius:8}}>
              <i data-lucide="upload" style={{width:28,height:28,color:drag?CD_TEAL:'#8a9bb5',margin:'0 auto 10px',display:'block'}}/>
              <div style={{fontSize:13,color:drag?CD_TEAL:'#d4e4fa',marginBottom:4}}>Drop PDF, DOCX, or image here</div>
              <div style={{fontSize:11,color:'#8a9bb5'}}>or click to browse</div>
            </div>
          )}
          {phase === 'processing' && (
            <div style={{padding:'40px 20px',textAlign:'center'}}>
              <div style={{width:32,height:32,border:`2px solid ${CD_TEAL}`,borderTopColor:'transparent',borderRadius:'50%',margin:'0 auto 16px',animation:'spin 800ms linear infinite'}}/>
              <div style={{fontSize:13,color:'#d4e4fa',marginBottom:4}}>Processing document…</div>
              <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>OCR · extraction · confidence scoring</div>
            </div>
          )}
          {phase === 'done' && (
            <div style={{padding:'40px 20px',textAlign:'center'}}>
              <i data-lucide="check-circle-2" style={{width:32,height:32,color:CD_TEAL,margin:'0 auto 14px',display:'block'}}/>
              <div style={{fontSize:13,color:'#d4e4fa',marginBottom:4}}>Document processed</div>
              <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5',marginBottom:16}}>confidence: 0.87 · INVOICE · auto-approved</div>
              <button onClick={()=>{onToast('Document uploaded · INV-2025-0461',CD_TEAL);onClose();}}
                style={{background:CD_TEAL,color:'#051424',border:'none',padding:'7px 20px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer'}}>Done</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ClearDeskScreen = ({ onToast }) => {
  const [status, setStatus] = React.useState('ALL');
  const [search, setSearch] = React.useState('');
  const [selected, setSelected] = React.useState(null);
  const [uploading, setUploading] = React.useState(false);

  React.useEffect(() => { lucide.createIcons(); });

  const filtered = CD_DOCS.filter(d =>
    (status==='ALL' || d.status===status) &&
    (!search || d.customer.toLowerCase().includes(search.toLowerCase()) || d.id.toLowerCase().includes(search.toLowerCase()))
  );

  const stats = [
    {label:'Total',     val:CD_DOCS.length,                                         color:'#d4e4fa'},
    {label:'Processed', val:CD_DOCS.filter(d=>d.status==='COMPLETED').length,       color:CD_TEAL},
    {label:'Processing',val:CD_DOCS.filter(d=>d.status==='PROCESSING').length,      color:'#FF6E00'},
    {label:'Pending',   val:CD_DOCS.filter(d=>d.status==='PENDING').length,         color:'#ffc400'},
    {label:'Escalated', val:CD_DOCS.filter(d=>d.status==='ESCALATED').length,       color:'#ff3b5c'},
  ];

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{padding:'16px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
        <div>
          <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>AR Document Processing</div>
          <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>ClearDesk</div>
        </div>
        <button onClick={()=>setUploading(true)}
          style={{background:CD_TEAL,color:'#051424',border:'none',padding:'7px 14px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
          <i data-lucide="upload" style={{width:13,height:13}}/>Upload
        </button>
      </div>
      <div style={{display:'flex',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
        {stats.map(s=>(
          <div key={s.label} style={{flex:1,padding:'12px 20px',borderRight:'1px solid #1c2b3c'}}>
            <div style={{fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:4}}>{s.label}</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:22,fontWeight:600,color:s.color}}>{s.val}</div>
          </div>
        ))}
      </div>
      <div style={{display:'flex',gap:8,padding:'10px 20px',borderBottom:'1px solid #1c2b3c',alignItems:'center',flexShrink:0,flexWrap:'wrap'}}>
        <div style={{position:'relative',flex:1,minWidth:160}}>
          <i data-lucide="search" style={{position:'absolute',left:9,top:'50%',transform:'translateY(-50%)',width:12,height:12,color:'#8a9bb5'}}/>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search documents…"
            style={{width:'100%',background:'#122131',border:'1px solid #273647',color:'#d4e4fa',fontSize:12,padding:'6px 10px 6px 28px',borderRadius:8,outline:'none',fontFamily:'Inter,sans-serif'}}/>
        </div>
        {['ALL','PENDING','PROCESSING','COMPLETED','ESCALATED'].map(s=>(
          <div key={s} onClick={()=>setStatus(s)} style={{fontSize:10,fontWeight:500,padding:'4px 10px',borderRadius:8,cursor:'pointer',transition:'all 150ms',background:status===s?`rgba(0,212,170,0.1)`:'transparent',color:status===s?CD_TEAL:'#8a9bb5',border:`1px solid ${status===s?'rgba(0,212,170,0.3)':'#1c2b3c'}`}}>{s}</div>
        ))}
      </div>
      <div style={{flex:1,overflow:'auto'}}>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead>
            <tr style={{background:'#122131',position:'sticky',top:0,zIndex:1}}>
              {['Document ID','Customer','Amount','Type','Priority','Status','Confidence','Assignee'].map(h=>(
                <th key={h} style={{padding:'7px 12px',textAlign:'left',fontSize:9,fontWeight:600,color:'#8a9bb5',letterSpacing:'0.07em',textTransform:'uppercase',borderBottom:'1px solid #273647',whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(doc=>(
              <tr key={doc.id} onClick={()=>setSelected(doc)} style={{borderBottom:'1px solid #1c2b3c',cursor:'pointer',transition:'background 100ms'}}
                onMouseEnter={e=>e.currentTarget.style.background='#122131'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{padding:'8px 12px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:CD_TEAL,whiteSpace:'nowrap'}}>{doc.id}</td>
                <td style={{padding:'8px 12px',fontSize:12,color:'#d4e4fa'}}>{doc.customer}</td>
                <td style={{padding:'8px 12px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:doc.amount>50000?'#ff3b5c':doc.amount>10000?'#ffc400':'#d4e4fa',whiteSpace:'nowrap'}}>${doc.amount.toLocaleString()}</td>
                <td style={{padding:'8px 12px',fontSize:10,color:'#8a9bb5'}}>{doc.type}</td>
                <td style={{padding:'8px 12px'}}><CDBadge label={doc.priority} s={CD_PRIORITY[doc.priority]}/></td>
                <td style={{padding:'8px 12px'}}><CDBadge label={doc.status} s={CD_STATUS[doc.status]}/></td>
                <td style={{padding:'8px 12px'}}><ConfBar val={doc.confidence}/></td>
                <td style={{padding:'8px 12px',fontSize:11,color:'#8a9bb5'}}>{doc.assignee||'—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length===0&&<div style={{padding:48,textAlign:'center',color:'#8a9bb5',fontSize:13}}>No documents match filters.</div>}
      </div>
      {selected && <CDDocDetail doc={selected} onClose={()=>setSelected(null)} onToast={onToast}/>}
      {uploading && <CDUploadModal onClose={()=>setUploading(false)} onToast={onToast}/>}
    </div>
  );
};

Object.assign(window, { ClearDeskScreen });
