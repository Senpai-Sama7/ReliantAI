// APEX.jsx — Autonomous Agent OS

const AP_PURPLE = '#7c5cfc';

const AP_DECISIONS = [
  { id:'wf-a9c3-d812', tier:'T3', confidence:0.63, stakes:'HIGH',   domain_novelty:0.41, aleatoric:0.28, epistemic:0.35, input:'Analyze Q2 revenue pipeline and identify top 3 at-risk accounts. Draft outreach email for each.', recommended:'APPROVE', layers:['L1 ✓ analyze','L2 ✓ calibration-gate','L3 ⟳ dispatch','L4 — quality-review'] },
  { id:'wf-b14f-c291', tier:'T4', confidence:0.44, stakes:'HIGH',   domain_novelty:0.91, aleatoric:0.41, epistemic:0.53, input:'Evaluate acquisition target: ClearPath HVAC Management SaaS — competitor intelligence, financial signals, strategic fit.', recommended:'REJECT', layers:['L1 ✓ analyze','L2 ✗ calibration-gate','L3 — dispatch','L4 — quality-review'] },
  { id:'wf-c88d-e047', tier:'T2', confidence:0.77, stakes:'MEDIUM', domain_novelty:0.22, aleatoric:0.14, epistemic:0.09, input:'Generate weekly operations summary for Douglas Mitchell covering all active services and key metrics.', recommended:'APPROVE', layers:['L1 ✓ analyze','L2 ✓ calibration-gate','L3 ✓ dispatch','L4 ⟳ quality-review'] },
];

const AP_TIER = {
  T1:{ color:'#FF6E00', bg:'rgba(255,110,0,0.08)',  border:'rgba(255,110,0,0.25)',  label:'Reflexive' },
  T2:{ color:'#ffc400', bg:'rgba(255,196,0,0.08)',  border:'rgba(255,196,0,0.25)',  label:'Deliberative' },
  T3:{ color:'#ff3b5c', bg:'rgba(255,59,92,0.08)',  border:'rgba(255,59,92,0.25)',  label:'Contested' },
  T4:{ color:AP_PURPLE, bg:'rgba(124,92,252,0.1)',  border:'rgba(124,92,252,0.35)', label:'Unknown', pulse:true },
};

const UncertaintyGauge = ({ aleatoric, epistemic, confidence }) => {
  const W = 180;
  const confW = confidence * W;
  const aleW  = (aleatoric / ((aleatoric + epistemic) || 1)) * W * (1 - confidence);
  const epiW  = (epistemic / ((aleatoric + epistemic) || 1)) * W * (1 - confidence);
  const cColor = confidence >= 0.9 ? '#FF6E00' : confidence >= 0.65 ? '#ffc400' : '#ff3b5c';
  return (
    <div style={{marginTop:10}}>
      <div style={{fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.07em',marginBottom:5}}>Uncertainty Breakdown</div>
      <div style={{width:W,height:8,background:'#1c2b3c',display:'flex',borderRadius:3,overflow:'hidden',marginBottom:6}}>
        <div style={{width:confW,background:cColor,transition:'width 400ms'}}/>
        <div style={{width:aleW,background:'rgba(255,59,92,0.55)'}}/>
        <div style={{width:epiW,background:`rgba(124,92,252,0.55)`}}/>
      </div>
      <div style={{display:'flex',gap:12}}>
        {[['conf',confidence.toFixed(2),cColor],['ale',aleatoric.toFixed(2),'rgba(255,59,92,0.9)'],['epi',epistemic.toFixed(2),'rgba(124,92,252,0.9)']].map(([k,v,c])=>(
          <div key={k} style={{display:'flex',alignItems:'center',gap:4}}>
            <div style={{width:7,height:7,borderRadius:3,background:c}}/>
            <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#8a9bb5'}}>{k} <span style={{color:'#d4e4fa'}}>{v}</span></span>
          </div>
        ))}
      </div>
    </div>
  );
};

const LayerTrace = ({ layers }) => {
  const colors = {'✓':'#00ff7a','✗':'#ff3b5c','⟳':'#ffc400','—':'#4a5e75'};
  return (
    <div style={{display:'flex',gap:6,marginTop:8,flexWrap:'wrap'}}>
      {layers.map((l,i) => {
        const sym = l.split(' ')[1];
        const color = colors[sym] || '#8a9bb5';
        return (
          <div key={i} style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color,background:'rgba(255,255,255,0.02)',border:`1px solid ${color}30`,padding:'2px 7px',borderRadius:3}}>
            {l}{sym==='⟳'&&<span style={{marginLeft:4,display:'inline-block',animation:'spin 1s linear infinite'}}>↻</span>}
          </div>
        );
      })}
    </div>
  );
};

const DecisionCard = ({ d, onDecide }) => {
  const ts = AP_TIER[d.tier];
  const [reasoning, setReasoning] = React.useState('');
  const [decided, setDecided] = React.useState(null);

  const decide = (action) => {
    setDecided(action);
    onDecide && onDecide(d.id, action, reasoning);
  };

  return (
    <div style={{background:'#0d1c2d',border:`1px solid ${decided?'#1c2b3c':AP_PURPLE+'40'}`,marginBottom:10,transition:'border 200ms',animation:'slide-in 200ms ease'}}>
      <div style={{padding:'11px 16px',borderBottom:'1px solid #1c2b3c',display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
        <div>
          <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',marginBottom:4}}>{d.id}</div>
          <div style={{display:'flex',gap:8,alignItems:'center'}}>
            <span style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:8,background:ts.bg,color:ts.color,border:`1px solid ${ts.border}`,letterSpacing:'0.04em',animation:ts.pulse?'pulse-p 2s ease infinite':undefined}}>{d.tier} · {ts.label}</span>
            <span style={{fontSize:10,color:'#8a9bb5'}}>stakes: <span style={{color:d.stakes==='HIGH'?'#ff3b5c':'#ffc400',fontFamily:'IBM Plex Mono,monospace'}}>{d.stakes}</span></span>
          </div>
        </div>
        <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:12,color:d.confidence>=0.65?'#ffc400':'#ff3b5c',fontWeight:600}}>conf: {d.confidence.toFixed(2)}</div>
      </div>
      <div style={{padding:'12px 16px',borderBottom:'1px solid #1c2b3c'}}>
        <div style={{fontSize:10,color:'#8a9bb5',marginBottom:3}}>Input</div>
        <div style={{fontSize:12,color:'#d4e4fa',lineHeight:1.6,marginBottom:0}}>{d.input}</div>
        <UncertaintyGauge aleatoric={d.aleatoric} epistemic={d.epistemic} confidence={d.confidence}/>
        <LayerTrace layers={d.layers}/>
      </div>
      {!decided ? (
        <div style={{padding:'11px 16px',display:'flex',gap:8,alignItems:'flex-end',flexWrap:'wrap'}}>
          <div style={{flex:1,minWidth:180}}>
            <div style={{fontSize:10,color:'#8a9bb5',marginBottom:3}}>Reasoning (optional)</div>
            <input value={reasoning} onChange={e=>setReasoning(e.target.value)}
              placeholder={`Recommended: ${d.recommended}`}
              style={{width:'100%',background:'#122131',border:'1px solid #273647',color:'#d4e4fa',fontSize:11,padding:'5px 9px',borderRadius:8,outline:'none',fontFamily:'Inter,sans-serif'}}/>
          </div>
          <button onClick={()=>decide('APPROVED')} style={{background:'rgba(0,255,122,0.1)',color:'#00ff7a',border:'1px solid rgba(0,255,122,0.3)',padding:'6px 14px',fontSize:11,fontWeight:600,borderRadius:8,cursor:'pointer'}}>Approve</button>
          <button onClick={()=>decide('REJECTED')} style={{background:'rgba(255,59,92,0.08)',color:'#ff3b5c',border:'1px solid rgba(255,59,92,0.3)',padding:'6px 14px',fontSize:11,fontWeight:600,borderRadius:8,cursor:'pointer'}}>Reject</button>
        </div>
      ) : (
        <div style={{padding:'10px 16px',display:'flex',alignItems:'center',gap:8}}>
          <div style={{width:6,height:6,borderRadius:'50%',background:decided==='APPROVED'?'#00ff7a':'#ff3b5c'}}/>
          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:decided==='APPROVED'?'#00ff7a':'#ff3b5c',fontWeight:600}}>{decided} · {new Date().toLocaleTimeString()}</span>
          {reasoning&&<span style={{fontSize:11,color:'#8a9bb5'}}>— "{reasoning}"</span>}
        </div>
      )}
    </div>
  );
};

const AP_AGENTS = [
  { name:'research_agent',  status:'IDLE',    calls:842,  success:'98.2%', lastRun:'14:31',  tools:['web_search','notion_read'] },
  { name:'analytics_agent', status:'RUNNING', calls:291,  success:'99.6%', lastRun:'14:32',  tools:['bap_query','sheets_write'] },
  { name:'creative_agent',  status:'IDLE',    calls:156,  success:'94.1%', lastRun:'13:55',  tools:['claude_generate','drive_write'] },
  { name:'sales_agent',     status:'IDLE',    calls:78,   success:'91.0%', lastRun:'12:18',  tools:['hubspot_crm','gmail_send'] },
];

const WorkflowRunner = ({ onToast }) => {
  const [input, setInput] = React.useState('');
  const [running, setRunning] = React.useState(false);
  const [result, setResult] = React.useState(null);

  const handleRun = () => {
    if(!input.trim()) return;
    setRunning(true); setResult(null);
    setTimeout(() => { setRunning(false); setResult({ tier:'T2', confidence:0.81, wfId:'wf-d9e1-f203' }); onToast&&onToast('Workflow submitted · wf-d9e1-f203', AP_PURPLE); }, 2400);
  };

  return (
    <div style={{padding:24,maxWidth:640}}>
      <div style={{fontSize:16,fontWeight:700,color:'#d4e4fa',marginBottom:4}}>Workflow Runner</div>
      <div style={{fontSize:12,color:'#8a9bb5',marginBottom:20}}>Submit a task to the APEX 5-layer agent pipeline.</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:20}}>
        {[['T1 Reflexive','>0.92 conf, low stakes','#FF6E00'],['T2 Deliberative','0.65–0.92 conf','#ffc400'],['T3 Contested','<0.65 or high stakes','#ff3b5c'],['T4 Unknown','domain novelty >0.85',AP_PURPLE]].map(([tier,desc,color])=>(
          <div key={tier} style={{background:'#0d1c2d',border:`1px solid ${color}20`,padding:'10px 14px'}}>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,fontWeight:600,color,marginBottom:2}}>{tier}</div>
            <div style={{fontSize:10,color:'#8a9bb5'}}>{desc}</div>
          </div>
        ))}
      </div>
      <div style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:16}}>
        <div style={{fontSize:10,color:'#8a9bb5',marginBottom:6}}>Workflow Input</div>
        <textarea value={input} onChange={e=>setInput(e.target.value)} rows={4}
          placeholder="Enter workflow input prompt…"
          style={{width:'100%',background:'#122131',border:'1px solid #273647',color:'#d4e4fa',fontSize:12,padding:'8px 12px',borderRadius:8,outline:'none',fontFamily:'Inter,sans-serif',resize:'none',marginBottom:10}}/>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <button onClick={handleRun} disabled={running||!input.trim()}
            style={{background:AP_PURPLE,color:'#d4e4fa',border:'none',padding:'8px 18px',fontSize:12,fontWeight:600,borderRadius:8,cursor:'pointer',opacity:running||!input.trim()?0.5:1}}>
            {running?'Running…':'Run Workflow →'}
          </button>
          {running && <div style={{width:14,height:14,border:`2px solid ${AP_PURPLE}`,borderTopColor:'transparent',borderRadius:'50%',animation:'spin 800ms linear infinite'}}/>}
        </div>
        {result && (
          <div style={{marginTop:14,padding:'10px 14px',background:`rgba(124,92,252,0.06)`,border:`1px solid rgba(124,92,252,0.2)`,borderLeft:`3px solid ${AP_PURPLE}`}}>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:AP_PURPLE,marginBottom:3}}>{result.wfId}</div>
            <div style={{fontSize:11,color:'#d4e4fa'}}>Tier: <span style={{fontFamily:'IBM Plex Mono,monospace',color:AP_TIER[result.tier].color}}>{result.tier} · {AP_TIER[result.tier].label}</span> · confidence: <span style={{fontFamily:'IBM Plex Mono,monospace',color:'#ffc400'}}>{result.confidence}</span></div>
          </div>
        )}
      </div>
    </div>
  );
};

const AgentsView = () => (
  <div style={{padding:24}}>
    <div style={{fontSize:16,fontWeight:700,color:'#d4e4fa',marginBottom:4}}>Registered Agents</div>
    <div style={{fontSize:12,color:'#8a9bb5',marginBottom:20}}>Specialist agents available in the APEX tool bus.</div>
    <div style={{display:'flex',flexDirection:'column',gap:6}}>
      {AP_AGENTS.map(a => (
        <div key={a.name} style={{background:'#0d1c2d',border:'1px solid #1c2b3c',padding:'12px 16px',display:'flex',gap:16,alignItems:'center'}}>
          <div style={{width:8,height:8,borderRadius:'50%',background:a.status==='RUNNING'?'#00ff7a':'#4a5e75',flexShrink:0,boxShadow:a.status==='RUNNING'?'0 0 6px #00ff7a80':undefined}}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:12,color:a.status==='RUNNING'?'#d4e4fa':'#d4e4fa',marginBottom:2}}>{a.name}</div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
              {a.tools.map(t=><span key={t} style={{fontSize:9,color:'#8a9bb5',background:'#122131',border:'1px solid #1c2b3c',padding:'1px 6px',borderRadius:8,fontFamily:'IBM Plex Mono,monospace'}}>{t}</span>)}
            </div>
          </div>
          <div style={{display:'flex',gap:20,flexShrink:0}}>
            {[['calls',a.calls],['success',a.success],['last run',a.lastRun]].map(([k,v])=>(
              <div key={k}><div style={{fontSize:9,color:'#8a9bb5',marginBottom:2}}>{k}</div><div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#d4e4fa'}}>{v}</div></div>
            ))}
            <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,padding:'2px 7px',borderRadius:8,background:a.status==='RUNNING'?'rgba(0,255,122,0.08)':'rgba(74,104,128,0.1)',color:a.status==='RUNNING'?'#00ff7a':'#8a9bb5',border:`1px solid ${a.status==='RUNNING'?'rgba(0,255,122,0.25)':'#1c2b3c'}`,alignSelf:'center'}}>{a.status}</span>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const APEXScreen = ({ onToast }) => {
  const [view, setView] = React.useState('hitl');
  const [log, setLog] = React.useState([]);

  React.useEffect(() => { lucide.createIcons(); });

  const handleDecide = (id, action, reason) => {
    setLog(l => [{id, action, reason, ts:new Date().toLocaleTimeString()}, ...l]);
    onToast && onToast(`${action}: ${id}`, action==='APPROVED'?'#00ff7a':'#ff3b5c');
    window._reliantBus && window._reliantBus.emit('event', {
      type: action==='APPROVED'?'agent.hitl_approved':'agent.hitl_rejected',
      source:'apex', payload:`wf_id: ${id}, action: ${action}`, color:AP_PURPLE,
    });
  };

  const VIEWS = ['hitl','workflows','agents','memory','tools'];

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{background:'#0d1c2d',borderBottom:'1px solid #1c2b3c',padding:'0 20px',height:48,display:'flex',alignItems:'center',gap:16,flexShrink:0}}>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <svg width="14" height="18" viewBox="0 0 16 24" fill="none">
            <polygon points="8,2 14,22 8,17 2,22" stroke={AP_PURPLE} strokeWidth="1.5" fill="none" strokeLinejoin="round"/>
          </svg>
          <span style={{fontSize:14,fontWeight:700,color:'#d4e4fa'}}>APEX</span>
          <span style={{fontSize:11,color:'#8a9bb5'}}>Autonomous Agent OS</span>
        </div>
        <div style={{flex:1}}/>
        {VIEWS.map(v=>(
          <div key={v} onClick={()=>setView(v)} style={{fontSize:12,color:view===v?'#d4e4fa':'#8a9bb5',cursor:'pointer',padding:'4px 0',borderBottom:view===v?`2px solid ${AP_PURPLE}`:'2px solid transparent',transition:'all 150ms',whiteSpace:'nowrap'}}>
            {v==='hitl'?'HITL Review':v.charAt(0).toUpperCase()+v.slice(1)}
          </div>
        ))}
        <div style={{display:'flex',alignItems:'center',gap:5,marginLeft:4}}>
          <div style={{width:6,height:6,borderRadius:'50%',background:'#00ff7a',boxShadow:'0 0 4px #00ff7a80'}}/>
          <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#8a9bb5'}}>SSE</span>
        </div>
      </div>

      {view==='hitl' && (
        <div style={{flex:1,display:'flex',overflow:'hidden'}}>
          <div style={{flex:1,overflow:'auto',padding:20,borderRight:'1px solid #1c2b3c'}}>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14}}>
              <div style={{fontSize:16,fontWeight:700,color:'#d4e4fa'}}>HITL Decision Queue</div>
              <div style={{background:'rgba(255,59,92,0.1)',color:'#ff3b5c',border:'1px solid rgba(255,59,92,0.25)',fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:8}}>{AP_DECISIONS.length} pending</div>
            </div>
            {AP_DECISIONS.map(d=><DecisionCard key={d.id} d={d} onDecide={handleDecide}/>)}
          </div>
          <div style={{width:260,overflow:'auto',padding:16,flexShrink:0}}>
            <div style={{fontSize:12,fontWeight:600,color:'#d4e4fa',marginBottom:12}}>Audit Log</div>
            {log.length===0 ? <div style={{fontSize:11,color:'#8a9bb5'}}>No decisions yet.</div>
            : log.map((l,i)=>(
              <div key={i} style={{padding:'8px 10px',borderBottom:'1px solid #1c2b3c',marginBottom:2}}>
                <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#4a5e75',marginBottom:2}}>{l.ts}</div>
                <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,fontWeight:600,color:l.action==='APPROVED'?'#00ff7a':'#ff3b5c',marginBottom:2}}>{l.action}</div>
                <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#8a9bb5'}}>{l.id}</div>
                {l.reason&&<div style={{fontSize:10,color:'#8a9bb5',marginTop:2}}>"{l.reason}"</div>}
              </div>
            ))}
          </div>
        </div>
      )}
      {view==='workflows' && <WorkflowRunner onToast={onToast}/>}
      {view==='agents' && <AgentsView/>}
      {(view==='memory'||view==='tools') && (
        <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:12}}>
          <div style={{width:40,height:2,background:AP_PURPLE}}/>
          <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif",textTransform:'capitalize'}}>{view}</div>
          <div style={{fontSize:12,color:'#8a9bb5',maxWidth:340,textAlign:'center',lineHeight:1.6}}>
            {view==='memory'&&'Semantic memory search + save. POST /memory/search · POST /memory/save. Top-k cosine results with similarity scores and namespace filtering.'}
            {view==='tools'&&'MCP Tool Bus — 15+ integrations: HubSpot, Notion, Stripe, Composio, Cloudflare KV. Circuit breaker and health status per connector.'}
          </div>
          <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#4a5e75'}}>/apex/{view}</div>
        </div>
      )}
    </div>
  );
};

Object.assign(window, { APEXScreen });
