// Money.jsx — HVAC AI Dispatch

const MN_GOLD = '#ffc400';

const MN_DISPATCHES = [
  { id:'DSP-2025-8821', customer:'Maria Sanchez',   phone:'+17135550182', issue:'Gas leak suspected — strong smell in unit 4B, elderly resident, no heat',         urgency:'LIFE_SAFETY', tech:'Rodriguez, M.', eta:'8 min',  status:'DISPATCHED', created:'14:28', address:'4821 Westheimer Rd, Houston TX 77056' },
  { id:'DSP-2025-8820', customer:'James Okafor',    phone:'+17135550291', issue:'AC not cooling — 96°F outside, system running but no cold air, infant in home',   urgency:'EMERGENCY',   tech:'Williams, T.', eta:'22 min', status:'EN_ROUTE',   created:'14:15', address:'2203 Richmond Ave, Houston TX 77098' },
  { id:'DSP-2025-8819', customer:'Linda Tran',      phone:'+17135550384', issue:'AC unit making loud grinding noise, started this morning',                         urgency:'URGENT',      tech:'Davis, K.',    eta:'45 min', status:'SCHEDULED',  created:'13:52', address:'5500 Bellaire Blvd, Houston TX 77401' },
  { id:'DSP-2025-8818', customer:'Robert Chen',     phone:'+17135550477', issue:'Thermostat unresponsive, unit cycling on/off every 2 minutes',                    urgency:'URGENT',      tech:'Martinez, J.', eta:'—',     status:'PENDING',    created:'13:41', address:'3100 Main St, Houston TX 77002' },
  { id:'DSP-2025-8817', customer:'Sandra Kim',      phone:'+17135550563', issue:'Annual maintenance check — filter replacement and refrigerant check',              urgency:'ROUTINE',     tech:'Williams, T.', eta:'—',     status:'COMPLETED',  created:'11:00', address:'7800 Kirby Dr, Houston TX 77030' },
  { id:'DSP-2025-8816', customer:'David Morales',   phone:'+17135550659', issue:'Water leak from indoor unit drip pan',                                            urgency:'URGENT',      tech:'Davis, K.',    eta:'—',     status:'COMPLETED',  created:'10:30', address:'1500 Post Oak Blvd, Houston TX 77056' },
];

const MN_URGENCY = {
  LIFE_SAFETY:{ bg:'rgba(255,59,92,0.12)',  color:'#ff3b5c', border:'#ff3b5c' },
  EMERGENCY:  { bg:'rgba(255,107,53,0.1)',  color:'#ff6b35', border:'rgba(255,107,53,0.5)' },
  URGENT:     { bg:'rgba(255,196,0,0.08)',  color:MN_GOLD,   border:'rgba(255,196,0,0.35)' },
  ROUTINE:    { bg:'rgba(0,255,122,0.06)',  color:'#00ff7a', border:'rgba(0,255,122,0.25)' },
};
const MN_STATUS_COLOR = { DISPATCHED:'#ff3b5c', EN_ROUTE:MN_GOLD, SCHEDULED:'#FF6E00', PENDING:'#8a9bb5', COMPLETED:'#00ff7a' };

const MNBadge = ({label,s}) => (
  <span style={{fontSize:9,fontWeight:700,padding:'2px 7px',borderRadius:8,background:s.bg,color:s.color,border:`1px solid ${s.border}`,letterSpacing:'0.05em',whiteSpace:'nowrap'}}>{label}</span>
);

const AgentTrace = ({dispatch}) => {
  const steps = [
    { agent:'triage_agent',    status:'done',    output:`urgency: ${dispatch.urgency} · escalate_owner: ${dispatch.urgency==='LIFE_SAFETY'}` },
    { agent:'intake_agent',    status:'done',    output:`customer: ${dispatch.customer} · issue captured · SMS sent` },
    { agent:'scheduler_agent', status:dispatch.status==='PENDING'?'running':'done', output:dispatch.status==='PENDING'?'Checking tech availability…':`tech: ${dispatch.tech} · eta: ${dispatch.eta}` },
    { agent:'dispatch_agent',  status:['PENDING','SCHEDULED'].includes(dispatch.status)?'pending':'done', output:['PENDING','SCHEDULED'].includes(dispatch.status)?'Waiting…':'Dispatch confirmed · SMS sent to customer' },
    { agent:'followup_agent',  status:dispatch.status==='COMPLETED'?'done':'pending', output:dispatch.status==='COMPLETED'?'Survey sent · 4.8★ received':'Scheduled for post-service' },
  ];
  const col = {done:'#00ff7a',running:MN_GOLD,pending:'#4a5e75'};
  return (
    <div>
      <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:10}}>CrewAI Agent Trace</div>
      {steps.map((s,i)=>(
        <div key={s.agent} style={{display:'flex',gap:10,marginBottom:0}}>
          <div style={{display:'flex',flexDirection:'column',alignItems:'center',width:16}}>
            <div style={{width:8,height:8,borderRadius:'50%',background:col[s.status],flexShrink:0,marginTop:3,boxShadow:s.status==='running'?`0 0 6px ${MN_GOLD}80`:undefined}}/>
            {i<steps.length-1&&<div style={{width:1,flex:1,background:'#1c2b3c',margin:'2px 0'}}/>}
          </div>
          <div style={{paddingBottom:10}}>
            <div style={{display:'flex',gap:8,alignItems:'baseline'}}>
              <span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:col[s.status],fontWeight:500}}>{s.agent}</span>
              {s.status==='running'&&<span style={{fontSize:10,color:MN_GOLD,animation:'spin 1s linear infinite',display:'inline-block'}}>↻</span>}
            </div>
            <div style={{fontSize:10,color:'#8a9bb5',marginTop:1,fontFamily:'IBM Plex Mono,monospace'}}>{s.output}</div>
          </div>
        </div>
      ))}
    </div>
  );
};

const MNDetail = ({d, onClose, onToast}) => {
  const [tab, setTab] = React.useState('details');
  const [saving, setSaving] = React.useState(false);
  const msgs = [
    {dir:'in',  text:`Hi, ${d.customer} here. ${d.issue}`, ts:'14:28:01'},
    {dir:'out', text:`Hello ${d.customer.split(' ')[0]}! We've received your request and are dispatching a technician immediately. You'll receive SMS updates.`, ts:'14:28:05'},
    {dir:'in',  text:'Thank you! Is there an ETA?', ts:'14:28:42'},
    {dir:'out', text:`${d.tech} is on the way — approximately ${d.eta}. We'll send a confirmation when they're close.`, ts:'14:28:45'},
  ];

  const handleSave = () => { setSaving(true); setTimeout(()=>{setSaving(false);onToast('Status updated · '+d.id,MN_GOLD);onClose();},800); };

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(1,10,25,0.88)',backdropFilter:'blur(12px)',WebkitBackdropFilter:'blur(12px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'rgba(18,33,49,0.95)',border:'1px solid rgba(255,110,0,0.15)',boxShadow:'0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(255,110,0,0.05)',width:620,maxHeight:'88vh',display:'flex',flexDirection:'column',borderRadius:8}} onClick={e=>e.stopPropagation()}>
        <div style={{padding:'13px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexShrink:0}}>
          <div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5',marginBottom:3}}>{d.id}</div>
            <div style={{fontSize:15,fontWeight:600,color:'#d4e4fa',marginBottom:6}}>{d.customer}</div>
            <div style={{display:'flex',gap:6,alignItems:'center'}}><MNBadge label={d.urgency} s={MN_URGENCY[d.urgency]}/><span style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:MN_STATUS_COLOR[d.status]}}>{d.status}</span></div>
          </div>
          <div onClick={onClose} style={{cursor:'pointer',color:'#8a9bb5',padding:4}}><i data-lucide="x" style={{width:15,height:15}}/></div>
        </div>
        <div style={{display:'flex',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
          {['details','messages','agents'].map(t=>(
            <div key={t} onClick={()=>setTab(t)} style={{padding:'8px 16px',fontSize:11,cursor:'pointer',color:tab===t?'#d4e4fa':'#8a9bb5',borderBottom:tab===t?`2px solid ${MN_GOLD}`:'2px solid transparent',transition:'all 150ms',textTransform:'capitalize'}}>{t==='agents'?'Agent Trace':t.charAt(0).toUpperCase()+t.slice(1)}</div>
          ))}
        </div>
        <div style={{flex:1,overflow:'auto',padding:'16px 20px'}}>
          {tab==='details'&&(
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px 24px'}}>
              {[['Customer',d.customer],['Phone',d.phone],['Address',d.address],['Technician',d.tech],['ETA',d.eta],['Created',d.created]].map(([k,v])=>(
                <div key={k}><div style={{fontSize:10,color:'#8a9bb5',marginBottom:3}}>{k}</div><div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:12,color:'#d4e4fa'}}>{v}</div></div>
              ))}
              <div style={{gridColumn:'1/-1'}}><div style={{fontSize:10,color:'#8a9bb5',marginBottom:4}}>Issue Summary</div><div style={{fontSize:12,color:'#d4e4fa',lineHeight:1.6}}>{d.issue}</div></div>
            </div>
          )}
          {tab==='messages'&&(
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              {msgs.map((m,i)=>(
                <div key={i} style={{display:'flex',justifyContent:m.dir==='out'?'flex-end':'flex-start'}}>
                  <div style={{maxWidth:'75%',padding:'8px 12px',background:m.dir==='out'?'rgba(255,196,0,0.06)':'#1c2b3c',border:`1px solid ${m.dir==='out'?'rgba(255,196,0,0.2)':'#273647'}`,borderRadius:8}}>
                    <div style={{fontSize:12,color:'#d4e4fa',lineHeight:1.5,marginBottom:3}}>{m.text}</div>
                    <div style={{fontSize:9,color:'#8a9bb5',fontFamily:'IBM Plex Mono,monospace'}}>{m.ts} · {m.dir==='out'?'outbound SMS':'inbound SMS'}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          {tab==='agents'&&<AgentTrace dispatch={d}/>}
        </div>
        <div style={{padding:'11px 20px',borderTop:'1px solid #1c2b3c',display:'flex',gap:8,flexShrink:0}}>
          <button onClick={handleSave} disabled={saving} style={{background:MN_GOLD,color:'#051424',border:'none',padding:'7px 14px',fontSize:12,fontWeight:700,borderRadius:8,cursor:'pointer',opacity:saving?0.7:1}}>{saving?'Saving…':'Update Status'}</button>
          <button style={{background:'transparent',color:'#d4e4fa',border:'1px solid #273647',padding:'7px 14px',fontSize:12,borderRadius:8,cursor:'pointer'}}>Resend SMS</button>
          <button style={{background:'transparent',color:'#d4e4fa',border:'1px solid #273647',padding:'7px 14px',fontSize:12,borderRadius:8,cursor:'pointer'}}>Add Note</button>
        </div>
      </div>
    </div>
  );
};

const MoneyScreen = ({ onToast }) => {
  const [selected, setSelected] = React.useState(null);
  const [showNew, setShowNew] = React.useState(false);
  const [tick, setTick] = React.useState(0);
  const hasLS = MN_DISPATCHES.some(d=>d.urgency==='LIFE_SAFETY'&&d.status!=='COMPLETED');

  React.useEffect(() => { lucide.createIcons(); });
  React.useEffect(() => { const t=setInterval(()=>setTick(n=>n+1),5000); return()=>clearInterval(t); },[]);

  const stats = [
    {label:'Total Today', val:MN_DISPATCHES.length,                                               color:'#d4e4fa'},
    {label:'Pending',     val:MN_DISPATCHES.filter(d=>d.status==='PENDING').length,               color:'#8a9bb5'},
    {label:'Active',      val:MN_DISPATCHES.filter(d=>['DISPATCHED','EN_ROUTE','SCHEDULED'].includes(d.status)).length, color:MN_GOLD},
    {label:'Completed',   val:MN_DISPATCHES.filter(d=>d.status==='COMPLETED').length,             color:'#00ff7a'},
    {label:'Emergency',   val:MN_DISPATCHES.filter(d=>['LIFE_SAFETY','EMERGENCY'].includes(d.urgency)).length, color:'#ff3b5c'},
    {label:'96°F Surge',  val:'ACTIVE', color:'#ff3b5c'},
  ];

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{padding:'16px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
        <div>
          <div style={{fontSize:10,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>HVAC AI Dispatch</div>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{fontSize:18,fontWeight:700,color:'#d4e4fa',fontFamily:"'Space Grotesk',sans-serif",fontFamily:"'Space Grotesk',sans-serif"}}>Money</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:9,color:'#8a9bb5'}}>Updated {tick>0?`${tick*5}s ago`:'just now'}</div>
            <div style={{width:6,height:6,borderRadius:'50%',background:'#00ff7a',boxShadow:'0 0 4px #00ff7a80'}}/>
          </div>
        </div>
        <button onClick={()=>setShowNew(true)} style={{background:MN_GOLD,color:'#051424',border:'none',padding:'7px 14px',fontSize:12,fontWeight:700,borderRadius:8,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
          <i data-lucide="plus" style={{width:13,height:13}}/>New Dispatch
        </button>
      </div>

      {hasLS && (
        <div style={{background:'rgba(255,59,92,0.08)',borderBottom:'2px solid #ff3b5c',padding:'9px 20px',display:'flex',alignItems:'center',gap:10,flexShrink:0,animation:'pulse-ls 1s ease infinite'}}>
          <i data-lucide="alert-triangle" style={{width:14,height:14,color:'#ff3b5c',flexShrink:0}}/>
          <div>
            <span style={{fontSize:12,fontWeight:700,color:'#ff3b5c'}}>LIFE_SAFETY — 911 Escalated · Owner Notified</span>
            <span style={{fontSize:11,color:'#ff3b5c',marginLeft:12,fontFamily:'IBM Plex Mono,monospace'}}>DSP-2025-8821 · 4821 Westheimer Rd · Rodriguez, M. en route · ETA 8 min</span>
          </div>
        </div>
      )}

      <div style={{display:'flex',borderBottom:'1px solid #1c2b3c',flexShrink:0}}>
        {stats.map((s,i)=>(
          <div key={s.label} style={{flex:1,padding:'10px 16px',borderRight: i<stats.length-1?'1px solid #1c2b3c':'none'}}>
            <div style={{fontSize:9,color:'#8a9bb5',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:4}}>{s.label}</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:20,fontWeight:600,color:s.color}}>{s.val}</div>
          </div>
        ))}
      </div>

      <div style={{flex:1,overflow:'auto'}}>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead>
            <tr style={{background:'#122131',position:'sticky',top:0,zIndex:1}}>
              {['Dispatch ID','Customer','Issue','Urgency','Technician','ETA','Status','Created'].map(h=>(
                <th key={h} style={{padding:'7px 12px',textAlign:'left',fontSize:9,fontWeight:600,color:'#8a9bb5',letterSpacing:'0.07em',textTransform:'uppercase',borderBottom:'1px solid #273647',whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {MN_DISPATCHES.map(d=>(
              <tr key={d.id} onClick={()=>setSelected(d)} style={{borderBottom:'1px solid #1c2b3c',cursor:'pointer',transition:'background 100ms'}}
                onMouseEnter={e=>e.currentTarget.style.background='#122131'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{padding:'8px 12px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:MN_GOLD,whiteSpace:'nowrap'}}>{d.id}</td>
                <td style={{padding:'8px 12px',fontSize:12,color:'#d4e4fa',whiteSpace:'nowrap'}}>{d.customer}</td>
                <td style={{padding:'8px 12px',fontSize:11,color:'#d4e4fa',maxWidth:200}}><div style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{d.issue}</div></td>
                <td style={{padding:'8px 12px'}}><MNBadge label={d.urgency} s={MN_URGENCY[d.urgency]}/></td>
                <td style={{padding:'8px 12px',fontSize:11,color:'#8a9bb5',whiteSpace:'nowrap'}}>{d.tech}</td>
                <td style={{padding:'8px 12px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#d4e4fa'}}>{d.eta}</td>
                <td style={{padding:'8px 12px',fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:MN_STATUS_COLOR[d.status],whiteSpace:'nowrap'}}>{d.status}</td>
                <td style={{padding:'8px 12px',fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>{d.created}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && <MNDetail d={selected} onClose={()=>setSelected(null)} onToast={onToast}/>}
      {showNew && <MNNewDispatch onClose={()=>setShowNew(false)} onToast={onToast}/>}
    </div>
  );
};

const MNNewDispatch = ({ onClose, onToast }) => {
  const [form, setForm] = React.useState({customer:'',phone:'',address:'',issue:'',urgency:'URGENT'});
  const [phase, setPhase] = React.useState('form');
  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const handleSubmit = () => {
    if(!form.customer||!form.issue) return;
    setPhase('processing');
    setTimeout(()=>{ setPhase('done'); },2000);
  };

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(1,10,25,0.88)',backdropFilter:'blur(12px)',WebkitBackdropFilter:'blur(12px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'rgba(18,33,49,0.95)',border:'1px solid rgba(255,110,0,0.15)',boxShadow:'0 20px 60px rgba(0,0,0,0.6)',width:480,borderRadius:8}} onClick={e=>e.stopPropagation()}>
        <div style={{padding:'14px 20px',borderBottom:'1px solid #1c2b3c',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div style={{fontSize:14,fontWeight:600,color:'#d4e4fa'}}>New Dispatch</div>
          <div onClick={onClose} style={{cursor:'pointer',color:'#8a9bb5'}}><i data-lucide="x" style={{width:15,height:15}}/></div>
        </div>
        {phase==='form' && (
          <div style={{padding:20,display:'flex',flexDirection:'column',gap:12}}>
            {[['Customer Name','customer','text'],['Phone','phone','tel'],['Address','address','text']].map(([label,key,type])=>(
              <div key={key}>
                <div style={{fontSize:10,color:'#8a9bb5',marginBottom:4}}>{label}</div>
                <input type={type} value={form[key]} onChange={e=>set(key,e.target.value)}
                  style={{width:'100%',background:'#0d1c2d',border:'1px solid #273647',color:'#d4e4fa',fontSize:12,padding:'7px 10px',borderRadius:8,outline:'none',fontFamily:'Inter,sans-serif'}}/>
              </div>
            ))}
            <div>
              <div style={{fontSize:10,color:'#8a9bb5',marginBottom:4}}>Issue Description</div>
              <textarea value={form.issue} onChange={e=>set('issue',e.target.value)} rows={3}
                style={{width:'100%',background:'#0d1c2d',border:'1px solid #273647',color:'#d4e4fa',fontSize:12,padding:'7px 10px',borderRadius:8,outline:'none',fontFamily:'Inter,sans-serif',resize:'none'}}/>
            </div>
            <div>
              <div style={{fontSize:10,color:'#8a9bb5',marginBottom:6}}>Urgency</div>
              <div style={{display:'flex',gap:6}}>
                {['ROUTINE','URGENT','EMERGENCY','LIFE_SAFETY'].map(u=>(
                  <div key={u} onClick={()=>set('urgency',u)} style={{padding:'4px 10px',fontSize:10,fontWeight:600,borderRadius:8,cursor:'pointer',background:form.urgency===u?`rgba(255,196,0,0.1)`:'transparent',color:form.urgency===u?MN_GOLD:'#8a9bb5',border:`1px solid ${form.urgency===u?'rgba(255,196,0,0.3)':'#1c2b3c'}`,transition:'all 150ms'}}>{u}</div>
                ))}
              </div>
            </div>
            <button onClick={handleSubmit} style={{background:MN_GOLD,color:'#051424',border:'none',padding:'8px 16px',fontSize:12,fontWeight:700,borderRadius:8,cursor:'pointer',marginTop:4}}>Submit Dispatch →</button>
          </div>
        )}
        {phase==='processing' && (
          <div style={{padding:'48px 20px',textAlign:'center'}}>
            <div style={{width:32,height:32,border:`2px solid ${MN_GOLD}`,borderTopColor:'transparent',borderRadius:'50%',margin:'0 auto 16px',animation:'spin 800ms linear infinite'}}/>
            <div style={{fontSize:13,color:'#d4e4fa',marginBottom:4}}>CrewAI processing dispatch…</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:10,color:'#8a9bb5'}}>triage → intake → scheduler → dispatch</div>
          </div>
        )}
        {phase==='done' && (
          <div style={{padding:'40px 20px',textAlign:'center'}}>
            <i data-lucide="check-circle-2" style={{width:32,height:32,color:MN_GOLD,margin:'0 auto 14px',display:'block'}}/>
            <div style={{fontSize:13,color:'#d4e4fa',marginBottom:4}}>Dispatch created</div>
            <div style={{fontFamily:'IBM Plex Mono,monospace',fontSize:11,color:'#8a9bb5',marginBottom:16}}>DSP-2025-8822 · Technician assigned · SMS sent</div>
            <button onClick={()=>{onToast('Dispatch DSP-2025-8822 created',MN_GOLD);onClose();}}
              style={{background:MN_GOLD,color:'#051424',border:'none',padding:'7px 20px',fontSize:12,fontWeight:700,borderRadius:8,cursor:'pointer'}}>Done</button>
          </div>
        )}
      </div>
    </div>
  );
};

Object.assign(window, { MoneyScreen });
