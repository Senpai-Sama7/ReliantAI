import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Bot, User, AlertCircle } from 'lucide-react';
import { Message } from '../types.ts';

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isBot = message.role === 'model';

  return (
    <div className={`flex w-full ${isBot ? 'justify-start' : 'justify-end'} mb-6 group`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] ${isBot ? 'flex-row' : 'flex-row-reverse'}`}>
        
        {/* Avatar */}
        <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center mt-1 
          ${isBot ? 'bg-brand-900 text-brand-500 mr-3 border border-brand-500/30' : 'bg-slate-800 text-slate-400 ml-3'}`}
        >
          {isBot ? <Bot size={18} /> : <User size={18} />}
        </div>

        {/* Message Bubble */}
        <div className={`relative flex flex-col ${isBot ? 'items-start' : 'items-end'}`}>
          <div className={`px-5 py-3.5 rounded-2xl shadow-sm
            ${isBot 
              ? 'bg-slate-800/80 border border-slate-700/50 text-slate-200 rounded-tl-sm' 
              : 'bg-brand-600 text-white rounded-tr-sm'
            }
            ${message.isError ? 'bg-red-900/50 border-red-500/50 text-red-200' : ''}
          `}>
            {message.isError ? (
              <div className="flex items-center gap-2">
                <AlertCircle size={16} className="text-red-400" />
                <span>{message.text}</span>
              </div>
            ) : (
              <div className="prose prose-invert prose-sm max-w-none leading-relaxed">
                {isBot ? (
                  <ReactMarkdown>{message.text}</ReactMarkdown>
                ) : (
                  <p className="whitespace-pre-wrap m-0">{message.text}</p>
                )}
              </div>
            )}
            
            {/* Streaming Indicator */}
            {message.isStreaming && (
              <span className="inline-block w-1.5 h-4 ml-1 align-middle bg-brand-500 animate-pulse"></span>
            )}
          </div>
          
          {/* Timestamp / Sender Name (Optional, keeping it clean for now) */}
          <span className="text-[10px] text-slate-500 mt-1 px-1 opacity-0 group-hover:opacity-100 transition-opacity">
            {isBot ? 'Reliant AI' : 'You'}
          </span>
        </div>
      </div>
    </div>
  );
};
