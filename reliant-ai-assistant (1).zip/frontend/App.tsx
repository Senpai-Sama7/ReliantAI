import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Send, Sparkles, Terminal, Server, Shield, Zap } from 'lucide-react';
import { Chat } from '@google/genai';
import { createChatSession } from './services/geminiService.ts';
import { Message } from './types.ts';
import { ChatMessage } from './components/ChatMessage.tsx';

const generateId = () => Math.random().toString(36).substring(2, 15);

const INITIAL_MESSAGE: Message = {
  id: 'init',
  role: 'model',
  text: "Hello! I'm the Reliant AI support assistant. How can I help you today? I can answer questions about our **microservices**, **pricing tiers**, or provide **contact information**.",
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>([INITIAL_MESSAGE]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Initialize chat session on mount
  useEffect(() => {
    try {
      chatSessionRef.current = createChatSession();
    } catch (error) {
      console.error("Failed to initialize chat session:", error);
      setMessages(prev => [...prev, {
        id: generateId(),
        role: 'model',
        text: "System Error: Unable to connect to the AI service. Please check your configuration.",
        isError: true
      }]);
    }
  }, []);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = useCallback(async () => {
    const trimmedInput = inputValue.trim();
    if (!trimmedInput || isLoading || !chatSessionRef.current) return;

    const userMsgId = generateId();
    const botMsgId = generateId();

    // 1. Add user message
    setMessages(prev => [...prev, { id: userMsgId, role: 'user', text: trimmedInput }]);
    setInputValue('');
    setIsLoading(true);

    // 2. Add placeholder for bot message
    setMessages(prev => [...prev, { id: botMsgId, role: 'model', text: '', isStreaming: true }]);

    try {
      // 3. Stream response
      const responseStream = await chatSessionRef.current.sendMessageStream({ message: trimmedInput });
      
      let fullResponse = '';
      for await (const chunk of responseStream) {
        if (chunk.text) {
          fullResponse += chunk.text;
          // Update the specific bot message with new chunks
          setMessages(prev => 
            prev.map(msg => 
              msg.id === botMsgId 
                ? { ...msg, text: fullResponse } 
                : msg
            )
          );
        }
      }

      // 4. Finalize bot message (remove streaming flag)
      setMessages(prev => 
        prev.map(msg => 
          msg.id === botMsgId 
            ? { ...msg, isStreaming: false } 
            : msg
        )
      );

    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => 
        prev.map(msg => 
          msg.id === botMsgId 
            ? { ...msg, text: "I'm sorry, I encountered an error while processing your request. Please try again later.", isStreaming: false, isError: true } 
            : msg
        )
      );
    } finally {
      setIsLoading(false);
      // Refocus input after sending
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  }, [inputValue, isLoading]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const suggestedQuestions = [
    "What microservices do you offer?",
    "Tell me about your pricing.",
    "How do I contact sales?",
    "What is the Agent Orchestrator?"
  ];

  return (
    <div className="flex h-full w-full bg-slate-950">
      
      {/* Left Sidebar - Branding & Info (Hidden on small screens) */}
      <div className="hidden lg:flex flex-col w-80 border-r border-slate-800 bg-slate-900/50 p-6">
        <div className="flex items-center gap-3 mb-10">
          <div className="bg-brand-500 p-2 rounded-lg">
            <Terminal size={24} className="text-slate-950" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">Reliant AI</h1>
            <p className="text-xs text-brand-400 font-medium">System Support</p>
          </div>
        </div>

        <div className="space-y-8 flex-grow">
          <div>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Core Capabilities</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-sm text-slate-300">
                <Server size={16} className="text-brand-500" />
                Microservices Architecture
              </li>
              <li className="flex items-center gap-3 text-sm text-slate-300">
                <Zap size={16} className="text-brand-500" />
                Low-Latency Inference
              </li>
              <li className="flex items-center gap-3 text-sm text-slate-300">
                <Shield size={16} className="text-brand-500" />
                Enterprise Reliability
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Quick Links</h3>
            <div className="flex flex-col gap-2">
              {suggestedQuestions.map((q, i) => (
                <button 
                  key={i}
                  onClick={() => setInputValue(q)}
                  className="text-left text-sm text-slate-400 hover:text-brand-400 hover:bg-slate-800/50 p-2 rounded transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-auto pt-6 border-t border-slate-800">
          <a href="https://github.com/senpai-sama7/reliantai" target="_blank" rel="noreferrer" className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-2">
            github.com/senpai-sama7/reliantai
          </a>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full relative">
        
        {/* Mobile Header */}
        <div className="lg:hidden flex items-center gap-3 p-4 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm z-10">
           <div className="bg-brand-500 p-1.5 rounded-md">
            <Terminal size={18} className="text-slate-950" />
          </div>
          <h1 className="text-lg font-bold text-white">Reliant AI Support</h1>
        </div>

        {/* Messages Container */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
          <div className="max-w-3xl mx-auto">
            {messages.map((msg) => (
              <ChatMessage key={msg.id} message={msg} />
            ))}
            <div ref={messagesEndRef} className="h-4" />
          </div>
        </div>

        {/* Input Area */}
        <div className="p-4 md:p-6 bg-gradient-to-t from-slate-950 via-slate-950 to-transparent">
          <div className="max-w-3xl mx-auto relative">
            <div className="relative flex items-end gap-2 bg-slate-900 border border-slate-700 rounded-2xl p-2 shadow-lg focus-within:border-brand-500/50 focus-within:ring-1 focus-within:ring-brand-500/50 transition-all">
              <textarea
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about microservices, pricing, or contact info..."
                className="flex-1 max-h-32 min-h-[44px] bg-transparent text-slate-200 placeholder-slate-500 resize-none outline-none py-2.5 px-3 text-sm leading-relaxed"
                rows={1}
                disabled={isLoading}
                style={{ height: 'auto' }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = `${Math.min(target.scrollHeight, 128)}px`;
                }}
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isLoading}
                className={`p-2.5 rounded-xl flex-shrink-0 transition-all ${
                  inputValue.trim() && !isLoading
                    ? 'bg-brand-600 text-white hover:bg-brand-500 shadow-md shadow-brand-900/20'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isLoading ? (
                  <Sparkles size={18} className="animate-pulse" />
                ) : (
                  <Send size={18} className={inputValue.trim() ? 'translate-x-0.5 -translate-y-0.5' : ''} />
                )}
              </button>
            </div>
            <div className="text-center mt-2">
              <span className="text-[10px] text-slate-600">
                AI responses may not always be accurate. Please verify important information.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
