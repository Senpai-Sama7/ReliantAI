# ReliantAI Technical Specification & System Architecture

## 1. System Overview
ReliantAI is an Autonomous Growth Engine designed to automate lead discovery, engagement, and conversion for service-based businesses. The system is built on a distributed microservices architecture.

## 2. Microservices Architecture (The "Citadel" Ecosystem)
The backend consists of 20+ purpose-built microservices. Key services include:

*   **Citadel (Identity & Access):** Handles AuthN/AuthZ, API gateway, and security headers.
*   **CyberArchitect (System Orchestrator):** Manages the deployment and scaling of other microservices.
*   **Backstage (Data Warehouse):** Centralized storage for lead data, campaign history, and performance metrics.
*   **Seeker (Discovery Service):** Scrapes and indexes local business data, social presence, and reviews.
*   **Evaluator (Quality Scoring):** Uses AI to rank leads based on multi-factor analysis.
*   **Nexus (Communication Engine):** Manages multi-channel outreach (Twilio for SMS/Voice, SendGrid for Email).
*   **Chronos (Task Scheduler):** Handles the timing of automated sequences and follow-ups.

## 3. API & Data Flow
### Lead Object Definition
```json
{
  "id": "uuid",
  "business_name": "string",
  "contact": { "email": "string", "phone": "string" },
  "quality_score": "float (0.0 - 1.0)",
  "source": "string (GMB, Yelp, LinkedIn)",
  "status": "enum (Discovered, Contacted, Nurturing, Converted)",
  "last_engagement": "timestamp"
}
```

## 4. Frontend Component Logic (Mobile App)
The app is a React Native / Flutter implementation consuming the Citadel API.

### Screen 1: Dashboard
*   **State Management:** Real-time WebSocket connection to `CyberArchitect` for activity feed updates.
*   **Components:** SummaryCards, ActivityList, GrowthChart.

### Screen 2: Lead Discovery
*   **Logic:** Integrates with `Seeker` and `Evaluator`.
*   **Interaction:** Users can "Approve" a lead to trigger the `Nexus` outreach sequence.

### Screen 3: Campaigns & Automation
*   **Logic:** Visualizes the `Chronos` schedule for active leads.
*   **Interaction:** Pause/Resume/Edit sequence nodes.
