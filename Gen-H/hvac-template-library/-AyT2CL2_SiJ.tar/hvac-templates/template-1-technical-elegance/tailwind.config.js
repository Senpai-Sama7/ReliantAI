/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
    './app/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: '#0f172a',
        charcoal: '#1a1a2e',
        copper: '#b87333',
        orange: '#ff6b00',
        cream: '#faf6f1',
        lightgray: '#e8e8e8',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      },
      keyframes: {
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideIn: {
          '0%': { opacity: '0', transform: 'translateX(-50px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        glow: {
          '0%, 100%': { boxShadow: '0 0 5px rgba(255, 107, 0, 0.5)' },
          '50%': { boxShadow: '0 0 20px rgba(255, 107, 0, 0.8)' },
        }
      },
      animation: {
        fadeInUp: 'fadeInUp 0.6s ease-out',
        slideIn: 'slideIn 0.6s ease-out',
        glow: 'glow 2s infinite',
      }
    },
  },
  plugins: [],
};