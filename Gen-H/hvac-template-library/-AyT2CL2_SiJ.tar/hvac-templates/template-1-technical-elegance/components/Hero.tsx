import React from 'react';
import { motion } from 'framer-motion';
import Button from './Button';

const Hero = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  };

  return (
    <section className="hero-gradient min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 bg-copper rounded-full opacity-10 blur-3xl"
          animate={{
            x: [0, 100, -100, 0],
            y: [0, -100, 100, 0],
          }}
          transition={{ duration: 20, repeat: Infinity }}
          style={{ top: '10%', left: '10%' }}
        />
        <motion.div
          className="absolute w-96 h-96 bg-orange rounded-full opacity-10 blur-3xl"
          animate={{
            x: [0, -100, 100, 0],
            y: [0, 100, -100, 0],
          }}
          transition={{ duration: 25, repeat: Infinity }}
          style={{ bottom: '10%', right: '10%' }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-4xl mx-auto text-center"
        >
          <motion.p variants={itemVariants} className="text-copper font-semibold text-lg uppercase tracking-widest mb-4">
            Premium HVAC Solutions
          </motion.p>

          <motion.h1
            variants={itemVariants}
            className="text-6xl md:text-7xl font-serif font-bold mb-6 leading-tight"
          >
            Climate Control
            <span className="gradient-text"> Perfected</span>
          </motion.h1>

          <motion.p variants={itemVariants} className="text-xl text-lightgray mb-8 max-w-2xl mx-auto leading-relaxed">
            Experience ultimate comfort with our advanced HVAC systems. Professional installation, 24/7 support, and 99.9% uptime guaranteed.
          </motion.p>

          <motion.div variants={itemVariants} className="flex gap-4 justify-center flex-wrap">
            <Button variant="primary" size="lg">
              Get Free Consultation
            </Button>
            <Button variant="secondary" size="lg">
              View Our Work
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div variants={itemVariants} className="mt-16 grid grid-cols-3 gap-8">
            {[
              { number: '500+', label: 'Installations' },
              { number: '20+', label: 'Years Experience' },
              { number: '24/7', label: 'Support Available' },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl font-serif font-bold text-orange mb-2">{stat.number}</div>
                <div className="text-sm text-lightgray">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 border-2 border-copper rounded-full flex justify-center">
          <motion.div className="w-1 h-2 bg-copper rounded-full mt-2" />
        </div>
      </motion.div>
    </section>
  );
};

export default Hero;