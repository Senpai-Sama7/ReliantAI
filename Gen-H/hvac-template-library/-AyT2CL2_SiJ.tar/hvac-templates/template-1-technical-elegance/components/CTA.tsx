import React from 'react';
import { motion } from 'framer-motion';
import Button from './Button';

const CTA = () => {
  return (
    <section className="py-24 bg-gradient-to-r from-navy via-charcoal to-navy relative overflow-hidden">
      <motion.div
        className="absolute inset-0 opacity-10"
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%'],
        }}
        transition={{ duration: 20, repeat: Infinity }}
      />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto text-center"
        >
          <h2 className="text-5xl font-serif font-bold mb-6">Ready to Experience Perfect Climate Control?</h2>
          <p className="text-xl text-lightgray mb-8">Schedule your free consultation today. Our experts will assess your needs and recommend the perfect solution.</p>

          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button variant="primary" size="lg">
              Schedule Free Consultation
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTA;