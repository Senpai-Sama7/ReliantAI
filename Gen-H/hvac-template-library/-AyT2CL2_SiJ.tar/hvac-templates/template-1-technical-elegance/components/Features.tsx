import React from 'react';
import { motion } from 'framer-motion';

const Features = () => {
  const features = [
    { title: 'Energy Efficient', desc: 'Save up to 40% on energy bills' },
    { title: '20+ Years', desc: 'Industry leading experience' },
    { title: 'Certified Team', desc: 'Licensed and insured professionals' },
    { title: 'Warranty', desc: '10-year equipment warranty' },
  ];

  return (
    <section className="py-20 bg-navy">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="text-center p-6"
            >
              <h3 className="text-xl font-serif font-bold mb-2 gradient-text">{feat.title}</h3>
              <p className="text-lightgray">{feat.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;