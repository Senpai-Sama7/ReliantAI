import React from 'react';
import { motion } from 'framer-motion';

const Services = () => {
  const services = [
    {
      icon: '❄️',
      title: 'Cooling Systems',
      description: 'State-of-the-art air conditioning with energy efficiency up to 20 SEER.',
    },
    {
      icon: '🔥',
      title: 'Heating Systems',
      description: 'High-efficiency furnaces with smart temperature control.',
    },
    {
      icon: '🔧',
      title: 'Maintenance Plans',
      description: 'Preventive maintenance to keep your system running smoothly.',
    },
    {
      icon: '🚨',
      title: '24/7 Emergency',
      description: 'Round-the-clock support when you need it most.',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
    },
  };

  return (
    <section className="py-24 bg-charcoal">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-serif font-bold mb-4">Our Services</h2>
          <p className="text-lightgray text-lg">Comprehensive HVAC solutions for your home and business</p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {services.map((service, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="bg-navy rounded-xl p-8 border border-copper border-opacity-20 hover:border-opacity-100 hover:shadow-xl hover:shadow-copper/20 transition-all duration-300"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-serif font-bold mb-3">{service.title}</h3>
              <p className="text-lightgray">{service.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;