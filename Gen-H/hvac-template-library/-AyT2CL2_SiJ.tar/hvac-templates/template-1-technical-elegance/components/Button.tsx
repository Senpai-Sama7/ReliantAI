import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  className = '',
}) => {
  const baseStyles = 'font-semibold rounded-lg transition-all duration-300 cursor-pointer font-sans';

  const variants: Record<string, string> = {
    primary: 'bg-orange text-white hover:bg-opacity-90 hover:shadow-lg hover:shadow-orange/50',
    secondary: 'bg-copper text-white hover:bg-opacity-90 hover:shadow-lg hover:shadow-copper/50',
    outline: 'border-2 border-copper text-copper hover:bg-copper hover:text-white',
  };

  const sizes: Record<string, string> = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {children}
    </motion.button>
  );
};

export default Button;