import React from 'react';
import Head from 'next/head';
import Hero from '@/components/Hero';
import Services from '@/components/Services';
import Features from '@/components/Features';
import CTA from '@/components/CTA';

export default function Home() {
  return (
    <>
      <Head>
        <title>Premium HVAC Solutions | Expert Climate Control</title>
        <meta name="description" content="Professional HVAC installation, repair, and maintenance services. 20+ years of experience, 24/7 emergency support." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <Hero />
        <Features />
        <Services />
        <CTA />
      </main>
    </>
  );
}