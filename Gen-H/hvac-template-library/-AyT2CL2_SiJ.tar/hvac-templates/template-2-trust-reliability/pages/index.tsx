import React, { useState } from 'react';
import { motion } from 'framer-motion';

export default function Home() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white shadow-lg z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Elite HVAC Services</h1>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
            Call Now: (555) 123-4567
          </button>
        </div>
      </nav>

      {/* Hero with image */}
      <section className="pt-20 min-h-screen flex items-center bg-gradient-to-br from-blue-50 to-gray-50">
        <div className="max-w-6xl mx-auto px-4 w-full grid md:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
            <h2 className="text-5xl font-bold text-gray-900 mb-6">Your Home Deserves Expert Care</h2>
            <p className="text-xl text-gray-600 mb-8">Trusted HVAC professionals with 20+ years of experience. Licensed, insured, and dedicated to your comfort.</p>
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700">
              Get Free Quote
            </button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-blue-200 rounded-lg h-96 flex items-center justify-center"
          >
            <span className="text-6xl">🔧</span>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">What Our Customers Say</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.2 }}
                className="bg-gray-50 p-8 rounded-lg border border-gray-200"
              >
                <div className="flex mb-4">
                  {[1, 2, 3, 4, 5].map((s) => <span key={s} className="text-yellow-400 text-xl">★</span>)}
                </div>
                <p className="text-gray-600 mb-4">
                  "Excellent service! Professional team, fair pricing, and they fixed our system in no time. Highly recommended!"
                </p>
                <p className="font-semibold text-gray-900">John Smith</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">Our Services</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {['Installation', 'Repair', 'Maintenance'].map((service, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-8 rounded-lg shadow-lg"
              >
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service}</h3>
                <p className="text-gray-600">Professional {service.toLowerCase()} services with guaranteed satisfaction.</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Don't Let Comfort Wait</h2>
          <p className="text-xl mb-8">Call us today for 24/7 emergency service</p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100">
            📞 (555) 123-4567
          </button>
        </div>
      </section>
    </div>
  );
}