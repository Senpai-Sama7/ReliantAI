# HVAC PREMIUM WEBSITE TEMPLATES

Complete, production-ready Next.js templates for HVAC companies.

## 4 Premium Templates Included

### 1. Technical Elegance
- **Style**: Split-screen, 3D product visualization, metrics
- **Best For**: Premium/high-tech HVAC companies
- **Features**: 
  - Hero with animated background
  - Service cards with hover effects
  - Animated stats
  - Interactive elements
  - Full Framer Motion animations

### 2. Trust & Reliability  
- **Style**: Team-focused, testimonials, approachable
- **Best For**: Local/residential HVAC services
- **Features**:
  - Customer testimonials carousel
  - Team section
  - Before/after gallery
  - Trust signals (certifications, years)
  - Easy-to-navigate layout

### 3. Performance Showcase
- **Style**: Data-driven, ROI focused, charts & graphs
- **Best For**: Commercial/enterprise HVAC
- **Features**:
  - Real-time performance charts (Recharts)
  - ROI calculator
  - Efficiency visualizations
  - Technical specifications
  - Metrics and analytics

### 4. Modern Minimalist
- **Style**: Clean, typography-forward, luxury feel
- **Best For**: Upscale brands
- **Features**:
  - Generous whitespace
  - Large, bold typography
  - Minimal decoration
  - Sophisticated interactions
  - Elegant simplicity

## Quick Start

### Requirements
- Node.js 16+
- npm or yarn

### Installation & Development

```bash
# Choose a template
cd template-1-technical-elegance

# Install dependencies
npm install

# Start development server
npm run dev

# Visit http://localhost:3000
```

### Production Build

```bash
npm run build
npm start
```

## File Structure

Each template includes:
```
template-x/
├── pages/
│   ├── _app.tsx         # App wrapper
│   ├── _document.tsx    # HTML document
│   └── index.tsx        # Home page
├── components/
│   ├── Hero.tsx
│   ├── Button.tsx
│   ├── Services.tsx
│   ├── Features.tsx
│   └── CTA.tsx
├── styles/
│   └── globals.css
├── public/              # Static assets
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── next.config.js
└── .env.example
```

## Customization

### Colors
Edit `tailwind.config.js` to customize colors:
```js
colors: {
  navy: '#0f172a',      // Change these
  copper: '#b87333',
  orange: '#ff6b00',
}
```

### Content
1. Edit company name in `.env`
2. Update page text in `pages/index.tsx`
3. Modify components in `components/`
4. Add images to `public/` folder

### Typography
Change fonts in `pages/_document.tsx`:
```tsx
<link href="https://fonts.googleapis.com/css2?family=YOUR_FONT&display=swap" rel="stylesheet" />
```

## Environment Variables

Copy `.env.example` to `.env.local`:
```env
NEXT_PUBLIC_COMPANY_NAME=Your Company Name
NEXT_PUBLIC_PHONE=(555) 123-4567
NEXT_PUBLIC_EMAIL=info@yourcompany.com
NEXT_PUBLIC_API_URL=http://localhost:5000
```

## Deployment

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm run build
# Deploy the 'out' folder
```

### Any Node Host
```bash
npm run build
npm start
```

## Performance

All templates are optimized for:
- ✅ 90+ Lighthouse score
- ✅ Mobile-responsive
- ✅ Fast load times
- ✅ SEO-friendly
- ✅ Accessible (WCAG 2.1)

## Technologies

- **Framework**: Next.js 14
- **UI**: React 18
- **Styling**: Tailwind CSS
- **Animations**: Framer Motion
- **Charts**: Recharts (Template 3)
- **Language**: TypeScript

## Features Included

### All Templates
- ✅ Responsive mobile design
- ✅ Smooth animations
- ✅ Call-to-action buttons
- ✅ Contact integration ready
- ✅ Dark/light mode (configurable)
- ✅ SEO optimized
- ✅ Fast performance

### Template-Specific
- **Template 1**: 3D graphics ready, advanced animations
- **Template 2**: Testimonial carousel, social proof
- **Template 3**: Charts, data visualization, ROI calculator
- **Template 4**: Minimalist design, elegant typography

## Customization Guide

### Add Your Logo
1. Place logo in `public/logo.png`
2. Import in header component

### Add Testimonials
Edit testimonial arrays in components:
```tsx
const testimonials = [
  { name: 'John', text: 'Great service!', rating: 5 },
  { name: 'Jane', text: 'Highly recommended', rating: 5 },
];
```

### Add Photos/Gallery
1. Add images to `public/images/`
2. Use Next.js Image component:
```tsx
import Image from 'next/image';
<Image src="/images/hvac-install.jpg" alt="Installation" />
```

### Connect to Backend
Update API calls in components:
```tsx
const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/leads`, {
  method: 'POST',
  body: JSON.stringify(formData),
});
```

## Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ✅ Mobile browsers

## Lighthouse Scores

Target:
- Performance: 90+
- Accessibility: 95+
- Best Practices: 90+
- SEO: 100

## Support & Documentation

Each template includes:
- Code comments explaining key sections
- Reusable components
- Example data structures
- Configuration examples

## License

Free to use, modify, and deploy.

## Quick Deploy Checklist

- [ ] npm install
- [ ] Create .env.local
- [ ] Update company info
- [ ] Add company logo
- [ ] Customize colors
- [ ] Add contact form backend
- [ ] npm run build
- [ ] Deploy to Vercel/Netlify
- [ ] Test on mobile
- [ ] Submit to search engines

## Next Steps

1. **Choose a template** - Pick the style that matches your brand
2. **Customize content** - Update copy, images, colors
3. **Add integrations** - Connect contact forms, payment, CRM
4. **Deploy** - Use Vercel for easiest deployment
5. **Monitor** - Track analytics and conversions

---

**Ready to launch?** Pick a template and start customizing!
