import React from 'react';
import { motion } from 'framer-motion';

export default function Home() {
  return (
    <div className="bg-white text-black">
      {/* Minimal Navigation */}
      <nav className="flex justify-between items-center p-8 max-w-6xl mx-auto">
        <h1 className="text-2xl font-light">HVAC</h1>
        <button className="text-lg hover:opacity-60">Get Quote</button>
      </nav>

      {/* Hero - Minimal */}
      <section className="min-h-screen flex items-center justify-center px-4">
        <div className="max-w-4xl text-center">
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="text-7xl font-light leading-tight mb-8"
          >
            The Art of Climate Control
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-xl text-gray-600 mb-12 leading-relaxed"
          >
            Elegantly engineered systems for the discerning home.
          </motion.p>
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
            whileHover={{ scale: 1.05 }}
            className="border-2 border-black px-8 py-3 text-lg hover:bg-black hover:text-white transition-all"
          >
            Explore
          </motion.button>
        </div>
      </section>

      {/* Services - Minimal Grid */}
      <section className="py-32 px-4 border-t border-gray-200">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-5xl font-light mb-16">Services</h2>
          <div className="grid md:grid-cols-3 gap-16">
            {['Installation', 'Maintenance', 'Emergency'].map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <h3 className="text-2xl font-light mb-4">{service}</h3>
                <p className="text-gray-600">Professional service with attention to detail.</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-32 px-4 bg-black text-white border-t border-gray-700">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-5xl font-light mb-8">Let's Talk</h2>
          <p className="text-xl text-gray-400 mb-8">(555) 123-4567</p>
        </div>
      </section>
    </div>
  );
}