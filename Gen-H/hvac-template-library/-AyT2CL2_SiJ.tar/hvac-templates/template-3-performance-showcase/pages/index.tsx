import React, { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

export default function Home() {
  const efficiencyData = [
    { month: 'Jan', efficiency: 92, savings: 1200 },
    { month: 'Feb', efficiency: 94, savings: 1400 },
    { month: 'Mar', efficiency: 96, savings: 1600 },
    { month: 'Apr', efficiency: 95, savings: 1500 },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Hero */}
      <section className="min-h-screen flex items-center justify-center text-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl font-bold mb-6"
          >
            Performance-Driven Climate Control
          </motion.h1>
          <p className="text-2xl text-blue-200 mb-8">Data-backed efficiency. Measurable savings.</p>
          <button className="bg-blue-500 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-600">
            See Your Potential Savings
          </button>
        </div>
      </section>

      {/* Performance Metrics */}
      <section className="py-20 bg-slate-800">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-white mb-12">System Performance</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="bg-slate-700 p-8 rounded-lg"
            >
              <h3 className="text-white text-xl font-bold mb-6">Efficiency Over Time</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={efficiencyData}>
                  <CartesianGrid stroke="#444" />
                  <XAxis stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip />
                  <Line type="monotone" dataKey="efficiency" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="bg-slate-700 p-8 rounded-lg"
            >
              <h3 className="text-white text-xl font-bold mb-6">Monthly Savings</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={efficiencyData}>
                  <CartesianGrid stroke="#444" />
                  <XAxis stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip />
                  <Bar dataKey="savings" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ROI Calculator */}
      <section className="py-20 bg-slate-900">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-white mb-12 text-center">ROI Calculator</h2>
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            className="bg-slate-800 p-8 rounded-lg"
          >
            <div className="grid md:grid-cols-3 gap-8">
              <div>
                <label className="text-white block mb-2">Square Footage</label>
                <input type="number" placeholder="2000" className="w-full p-3 rounded bg-slate-700 text-white" />
              </div>
              <div>
                <label className="text-white block mb-2">Current System Age</label>
                <input type="number" placeholder="15" className="w-full p-3 rounded bg-slate-700 text-white" />
              </div>
              <div>
                <label className="text-white block mb-2">Monthly Energy Bill</label>
                <input type="number" placeholder="250" className="w-full p-3 rounded bg-slate-700 text-white" />
              </div>
            </div>
            <button className="mt-6 w-full bg-blue-500 text-white py-3 rounded-lg font-bold hover:bg-blue-600">
              Calculate Savings →
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}